/**
 * 
 */

/**
 * @author Koppala_Choleswaraia
 *
 */
 class A {

	public void show() {
		 System.out.println("parent Nullpointer exception");

		throw new RuntimeException();
	}
	 public static void main(String[] args) {
			
		 B b = new B();
		 b.show();
	}
}

 
 class B extends A{
	 
	 @Override
	public void show() {
		// TODO Auto-generated method stub
		 System.out.println("child arithmatic exception");

		 throw new ArithmeticException();
	}
	
 }

