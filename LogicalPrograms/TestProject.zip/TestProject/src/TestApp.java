/**
 * 
 */

/**
 * @author Koppala_Choleswaraia
 *
 */
public class TestApp {

	MyNode head;

	public MyNode insertData(int data) {

		MyNode node = new MyNode();
		node.data = data;
		node.next = null;

		if (head == null) {

			head = node;
		} else {

			MyNode n = head;
			while (n.next != null) {

				n = n.next;
			}
			n.next = node;
		}
		return node;
	}

	public void deleteAtElement(int index) {

		if (index == 0) {

			head = head.next;
		}
		MyNode n = head.next;
		MyNode n1 = null;

		for (int i = 0; i < index - 1; i++) {

			n = n.next;

		}
		n1 = n.next;

		n.next = n1.next;
	}
	
	

	public MyNode reverseLinkedList(MyNode head1) {
		
		MyNode node=head1;
		MyNode prev=null;
		MyNode current=node;
		MyNode next=null;
		
		while(current!=null) {
			
			next=current.next;
			current.next=prev;
			prev=current;
			current=next;
		}
		node=prev;
		return node;
	}
	public void print(MyNode head) {

		MyNode res = head;
		while (res.next != null) {

			System.out.println(res.data);
			res = res.next;
		}
		System.out.println(res.data);
	}

	public static void main(String[] args) {

		TestApp test = new TestApp();
		MyNode node=new MyNode();
		node=test.insertData(10);
		node.next=test.insertData(20);
		node.next.next=test.insertData(30);
		node.next.next.next=test.insertData(40);

		node=test.reverseLinkedList(node);
		//test.deleteAtElement(1);
		test.print(node);

	}

}
