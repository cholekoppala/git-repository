import java.util.List;
import java.util.stream.Collectors;

class Main {

    public static void main(String[] args) {
        List<Employee> employees = List.of(
                new Employee("Alice", 30, 60000),
                new Employee("Bob", 35, 75000),
                new Employee("Charlie", 28, 50000),
                new Employee("David", 40, 80000),
                new Employee("Eva", 35, 55000)
        );
        
        //find average
        Double average = employees.stream()
        .collect(Collectors.averagingDouble(Employee::getAge));
        
        //filter salary 50000
        
        List<Employee> salary = employees.stream()
        .filter(es->50000<es.getSalary())
        .collect(Collectors.toList());
        
        //calculate totalsalary all employees
        
        double sum = employees.stream().mapToDouble(Employee::getSalary).sum();
        double sum1 = employees.stream().collect(Collectors.summarizingDouble(Employee::getSalary)).getSum();
        
        System.out.println(sum);
        
        System.out.println(average);
        System.out.println(salary);
        System.out.println(sum);
        System.out.println(sum1);
        
        
   }
}