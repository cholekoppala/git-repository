/**
 * 
 */

/**
 * @author Koppala_Choleswaraia
 *
 */
public class MyLinkedList {

	Node head;

	public Node insertData(int data) {

		Node node = new Node(data);
		node.data = data;
		node.next = null;

		if (head == null) {

			head = node;
		}

		else {

			Node n = head;

			while (n.next != null) {

				n = n.next;
			}

			n.next = node;
		}
		return node;
	}
	public int headcountofNodes(Node head) {
		
		int count=0;
		while(head!=null) {
			
			head=head.next;
			count++;
		}		
		return count;
	}
	
	public Node middleDeletion(Node head) {
		
		if(head==null) {
			
			return null;
		}
		if(head.next==null) {
			
			return null;
		}
		
		else {
			Node copyofhead=head;
			int count=headcountofNodes(head);
			
			int mid=count/2;
			
			while(mid-->1) {
				
				head=head.next;
			}
			head.next=head.next.next;
			return copyofhead;
		}
	}
	
	public void deleteElement(int index) {
		
		if(index==0) {
			
			head=head.next;
		}
		
		else {
			
			Node n=head;
			Node n1=null;
			
			for(int i=0;i<index-1;i++) {
				
				n=n.next;
			}
			n1=n.next;
			n.next=n1.next;
		}
	}

	public Node reverseLinkedlist() {

		Node node = head;
		Node prev = null;
		Node current = node;
		Node next = null;

		while (current != null) {

			next = current.next;
			current.next = prev;
			prev = current;
			current = next;
		}
		node = prev;
		return node;
	}

	public void print() {

		Node res = head;

		while (res.next != null) {
			System.out.println(res.data);
			res = res.next;
		}
		System.out.println(res.data);
	}

	public static void main(String[] args) {

		MyLinkedList obj = new MyLinkedList();

		obj.head = obj.insertData(10);
		obj.head.next = obj.insertData(20);
		obj.head.next.next = obj.insertData(30);
		obj.head.next.next.next = obj.insertData(40);
		//obj.head=obj.reverseLinkedlist();
		obj.deleteElement(1);
		//obj.middleDeletion(obj.head);
		obj.print();

	}

}
