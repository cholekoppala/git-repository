import java.util.Arrays;

/**
 * 
 */

/**
 * @author Koppala_Choleswaraia
 *
 */
public class Sort {
	
	public static int[] sort(int[] arr,int start,int end) {
	
		if(end<=start) {
			return arr;
		}
		int pivot=partition(arr,start,end);
		sort(arr,start,pivot-1);
		sort(arr,pivot+1,end);
		
		return arr;
	
	}
	
	public static int partition(int[] arr,int start,int end) {
		
		int pivot=arr[end];
		int i=start-1;
		
		for(int j=start;j<=end;j++) {
			
			if(arr[j]<pivot) {
				
				i++;
				int temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
		i++;
		int temp=arr[i];
		arr[i]=arr[end];
		arr[end]=temp;
		return i;
	}
	

	public static void main(String[] args) {
		
		int[] arr= {10,40,70,80,20};
		int[] sort = sort(arr,0,arr.length-1);
		
		System.out.println(Arrays.toString(sort));
		
		
	}

}
