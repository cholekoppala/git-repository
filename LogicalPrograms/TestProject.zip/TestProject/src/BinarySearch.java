/**
 * 
 */

/**
 * @author Koppala_Choleswaraia
 *
 */
public class BinarySearch {

	public static int binarysearch(int[] arr, int key) {

		int low = 0;
		int high = arr.length - 1;

		while (low <= high) {

			int mid = low + high / 2;
			int middleIndex = arr[mid];

			if (key == middleIndex) {

				return mid;
			} else if (key < middleIndex) {

				high = mid - 1;
			} else if (key > middleIndex) {

				low = mid + 1;
			}
		}
		return -1;

	}

	public static void main(String[] args) {

		int[] arr = { 10, 20, 30, 40, 50 };

		int key = 30;
		int binarysearch = binarysearch(arr, key);
		System.out.println(binarysearch);
	}

}
