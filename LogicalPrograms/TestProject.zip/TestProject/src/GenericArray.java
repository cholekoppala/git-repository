import java.util.Arrays;

/**
 * 
 */

/**
 * @author Koppala_Choleswaraia
 *
 */
public class GenericArray<T> {
	
	private Object[] generalArray;
	
	public GenericArray(int size) {
		// TODO Auto-generated constructor stub
		
		generalArray=new Object[size];
	}
	
	public T get(int index) {
		
		return (T)get(index);
	}
	
	public void set(int index,T element) {
		
		generalArray[index]=element;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return Arrays.toString(generalArray);
	}
	public static void main(String[] args) {
		Integer[] arr= {10,20,30,40,50};
		GenericArray<Integer> obj = new GenericArray<>(arr.length);
	

		
		
	}
}
