/**
 * 
 */
package com.java.linkedlist;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class MyCustomLinkedList {

	Node head;

	public Node insertData(int data) {

		Node node = new Node();

		node.data = data;
		node.next = null;

		if (head == null) {

			head = node;
		} else {

			Node n = head;

			while (n.next != null) {

				n = n.next;
			}
		}
		return node;
	}

	public void deleteElement(int index) {

		if (index == 0) {

			head = head.next;
		} else {

			Node n = head;
			Node n1 = null;

			for (int i = 0; i < index - 1; i++) {

				n = n.next;
			}
			n1 = n.next;
			n.next = n1.next;
		}
	}

	public Node reverseLinkedList() {

		Node node = head;
		Node prev = null;
		Node current = node;
		Node next = null;

		while (current.next != null) {

			next = current.next;
			current.next = prev;
			prev = current;
			current = next;
		}
		node = prev;
		return node;
	}

	public Node middleDeletion(Node head) {

		Node copyHead = head;

		if (head == null) {

			return null;
		}
		if (head.next == null) {

			return null;
		}

		int countofNodes = countofNodes(copyHead);

		int mid = countofNodes / 2;

		while (mid-- > 1) {

			head = head.next;
		}
		head.next = head.next.next;

		return copyHead;

	}

	public int countofNodes(Node head) {

		int count = 0;
		while (head.next != null) {

			head = head.next;
			count++;
		}
		return count;
	}

	public void print() {

		Node res = head;

		while (res.next != null) {

			System.out.println(res.data);
			res = res.next;
		}

		System.out.println(res.data);

	}

	public static void main(String[] args) {

		MyCustomLinkedList linkedList = new MyCustomLinkedList();

		linkedList.head = linkedList.insertData(10);
		linkedList.head.next = linkedList.insertData(20);
		linkedList.head.next.next = linkedList.insertData(30);
		linkedList.head.next.next.next = linkedList.insertData(40);
		linkedList.head.next.next.next.next = linkedList.insertData(50);

		// linkedList.head=linkedList.reverseLinkedList();
		// linkedList.deleteElement(0);
		
		linkedList.head=linkedList.middleDeletion(linkedList.head);
		linkedList.print();


	}

}
