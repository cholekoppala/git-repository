/**
 * 
 */
package com.java.linkedlist;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class Node {
	
	int data;
	Node next;
	
	Node(){
		
		
	}

}
