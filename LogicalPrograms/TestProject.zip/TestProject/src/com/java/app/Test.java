package com.java.app;

import java.util.Arrays;

class Test {

	public static int[] multi(String[][] stringArr,String keyString) {
		
		int[] result= {-1,-1};
		
		for(int i=0;i<stringArr.length;i++) {
			
			for(int j=0;j<stringArr[i].length;j++) {
				
				if(stringArr[i][j].equals(keyString)) {
					
					result[0]=i;
					result[1]=j;
				}
			}
		}
		return result;
	}
	public static void main(String[] args) {
		
		
		String[][] stringArr = { { "a", "h", "b" }, { "c", "d", "e" }, { "g", "t", "r" } };

		String keyString = "e";

        int[] multi = multi(stringArr, keyString);
        System.out.println(Arrays.toString(multi));
	}

}

class Employee1 {

	private String empName;
	private Integer empId;
	private Integer empSal;
	private Double empAvgSal;
	private String empDept;

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public Integer getEmpSal() {
		return empSal;
	}

	public void setEmpSal(Integer empSal) {
		this.empSal = empSal;
	}

	public Double getEmpAvgSal() {
		return empAvgSal;
	}

	public void setEmpAvgSal(Double empAvgSal) {
		this.empAvgSal = empAvgSal;
	}

	public String getEmpDept() {
		return empDept;
	}

	public void setEmpDept(String empDept) {
		this.empDept = empDept;
	}

	@Override
	public String toString() {
		return "Employee1 [empName=" + empName + ", empId=" + empId + ", empSal=" + empSal + ", empAvgSal=" + empAvgSal
				+ ", empDept=" + empDept + "]";
	}

	public Employee1(String empName, Integer empId, Integer empSal, Double empAvgSal, String empDept) {
		super();
		this.empName = empName;
		this.empId = empId;
		this.empSal = empSal;
		this.empAvgSal = empAvgSal;
		this.empDept = empDept;
	}

}