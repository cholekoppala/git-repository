package com.java.app;

public class B implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub

		for (int i = 1; i <= 10; i++) {

			System.out.println("chaild thread");
		}

	}

	public static void main(String[] args) {
		
		B obj=new B();
		
		Thread t=new Thread(obj);
		t.start();
		
		for(int i=1;i<=10;i++) {
			
			System.out.println("parent thread");
		}
		

	}
}
