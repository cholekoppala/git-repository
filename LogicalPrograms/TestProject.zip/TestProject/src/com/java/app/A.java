package com.java.app;

public class A extends Thread {

	@Override
	public void run() {
		for (int i = 1; i <= 10; i++) {
			System.out.println("chaild thread");

		}
	}

	public static void main(String[] args) {
		
		A obj=new A();
		obj.start();
		
		for(int i=1;i<=10;i++) {
			
			
			System.out.println("parent thread");
		}

	}
}
