package com.java.app;

import java.util.Optional;

class Employee {
	boolean isPerm;
	boolean isManager;
}

boolean callAnotherMethd(e){
    // somthing
}

methodA(Employee e) {
if(e==null)
{
     throw new CustomException();
}
else
{
     callAnotherMethd(e);
}
}

Optional.ofNullable(e).filter(e->e.get()==null)
.OrElseThrow(()->new RuntimeException());