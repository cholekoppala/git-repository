package com.java.functionInterface;

import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class AppInterface {

	public static void main(String[] args) {

//		Consumer c=(a,b)->{
//			
//			System.out.println(a+b);
//		};
//		c.add(10, 20);
//	}

//		Consumer<String> cc=(s)->{
//			
//			System.out.println(s);
//		};
//		cc.accept("hello");

//		Supplier s=()->{
//			
//			return "chole";
//		};
//		System.out.println(s.get());

//		Supplier<String> str=()->{
//			
//			return "hello supplier";
//		};
//       System.out.println(str.get());

//		Predicate p=(s1,s2)->{
//			
//			return s1.equals(s2);
//		};
//		System.out.println(p.checkingTwoStrings("chole", "chole"));

//		Predicate<Integer> p = (i -> i > 1);
//		System.out.println(p.test(10));

		Function<Integer, Integer> f = (a) -> {

			return a;
		};
		System.out.println(f.apply(10));
	}

}
