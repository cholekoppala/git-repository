package com.java.functionInterface;

public interface Consumer {
	
	void add(int a,int b);

}
