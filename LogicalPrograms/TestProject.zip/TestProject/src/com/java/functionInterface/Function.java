package com.java.functionInterface;

public interface Function {
	
	
	public Integer evenOrOdd(int no);

}
