package com.java.functionInterface;

public interface Predicate {
	
	boolean checkingTwoStrings(String s1,String s2);

}
