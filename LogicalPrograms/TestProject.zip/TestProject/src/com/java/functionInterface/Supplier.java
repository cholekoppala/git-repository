package com.java.functionInterface;

public interface Supplier {
	
	String get();

}
