package com.java.classes;

public class Employee {

	private Integer empId;
	private String empName;
	private Double empSal;
	private String empAddr;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(Integer empId, String empName, Double empSal, String empAddr) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empAddr = empAddr;
	}

	/**
	 * @return the empId
	 */
	public Integer getEmpId() {
		return empId;
	}

	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	/**
	 * @return the empName
	 */
	public String getEmpName() {
		return empName;
	}

	/**
	 * @param empName the empName to set
	 */
	public void setEmpName(String empName) {
		this.empName = empName;
	}

	/**
	 * @return the empSal
	 */
	public Double getEmpSal() {
		return empSal;
	}

	/**
	 * @param empSal the empSal to set
	 */
	public void setEmpSal(Double empSal) {
		this.empSal = empSal;
	}

	/**
	 * @return the empAddr
	 */
	public String getEmpAddr() {
		return empAddr;
	}

	/**
	 * @param empAddr the empAddr to set
	 */
	public void setEmpAddr(String empAddr) {
		this.empAddr = empAddr;
	}

	

}
