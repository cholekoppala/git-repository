package com.java.classes;

import java.util.Comparator;

public class EmployeeNameComparator implements Comparator{

	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		return o1.getEmpName().compareTo(o2.getEmpName());
	}

	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		Employee e1=(Employee)o1;
		Employee e2=(Employee)o2;

		return e1.getEmpName().compareTo(e2.getEmpName());
	}
	
	

}
