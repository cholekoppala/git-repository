package com.java.classes;

import java.util.Comparator;

public class EmployeeComparatorBySalary implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		
		if(o1.getEmpSal()==o2.getEmpSal()) {
			
			return 0;
			
		}
		else if(o1.getEmpSal()>o2.getEmpSal()) {
		return 1;
	}
	return -1;

}
}