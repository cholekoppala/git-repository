package com.java.classes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmployeeApp {
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		
		Employee e1 = new Employee(123, "satheesh", 98876.00, "hyd");
		Employee e2 = new Employee(355, "chakri", 87655.00, "bang");
		Employee e3 = new Employee(987, "bathi", 100000.00, "chennai");
		Employee e4 = new Employee(432, "ajay", 456778.00, "mumbai");
		
		List<Employee> list = new ArrayList<>();
		list.add(e1);
		
		list.add(e2);
		list.add(e3);
		list.add(e4);

	//	Collections.sort(list,new EmployeeNameComparator());
		
		Collections.sort(list,new EmployeeComparatorBySalary());
		
		list.forEach((res)->{
			
			//System.out.println(res.getEmpName());
			System.out.println(res.getEmpSal());

		});
		
	}

}
