package com.java.classes;
class Solution {
final Employee employee;
public Solution() {
employee = new Employee(12, "chole", 9877.9, "hyd");//line1
}
 
public void changeEmployee() {
employee.setEmpName("chole");
}
 
}