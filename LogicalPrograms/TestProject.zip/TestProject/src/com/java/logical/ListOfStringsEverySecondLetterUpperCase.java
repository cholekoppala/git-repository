package com.java.logical;

import java.util.Arrays;
import java.util.List;

public class ListOfStringsEverySecondLetterUpperCase {
	
	public static void main(String[] args) {
		
		List<String> asList = Arrays.asList("hyderabad","banglore","chennai");
		
		for (String string : asList) {
			
			String secondLetter=string.substring(1,2);
			String firstLetter = string.substring(0,1);
			String remaingLetter=string.substring(2,string.length());
			
			String finalResult=firstLetter+secondLetter.toUpperCase()+remaingLetter;
			System.out.println(finalResult);
			
		}
	}

}
