package com.java.logical;

//https://www.tabnine.com/code/java/methods/java.util.Optional/orElseThrow
public class StringFirstLetterUpperCase {

	public static void main(String[] args) {

		String str = "chole";

		String secondLetter = str.substring(1, 2);
		String firstLetter = str.substring(0, 1);

		String remaingLetter = str.substring(2, str.length());

		String finalResult = firstLetter + secondLetter.toUpperCase() + remaingLetter;

		System.out.println(finalResult);
	}

}
