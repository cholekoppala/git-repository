package com.java.logical;

import java.util.ArrayList;
import java.util.List;

public class ConcurrentModifierException {

	public static void main(String[] args) {

		List<Integer> ls = new ArrayList<>();

		ls.add(10);
		ls.add(20);
		ls.add(30);
		ls.add(40);
		ls.add(50);

		for (Integer integer : ls) {

			if (integer.equals(20)) {

				ls.remove(1);
			}
		}

	}

}
