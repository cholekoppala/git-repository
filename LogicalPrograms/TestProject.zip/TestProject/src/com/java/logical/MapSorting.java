package com.java.logical;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class MapSorting {
	
	public static void main(String[] args) {
		
		Map<String, Integer> map = Map.of("chole",123,"siva",156,"anad",987,"subuu",765);
		System.out.println("Before sorting--"+map);
		LinkedHashMap<String, Integer> sort = map.entrySet().stream().sorted(Map.Entry.<String,Integer>comparingByKey())
		.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,(e1,e2)->e1,LinkedHashMap::new));
		
		System.out.println("After sorting--"+sort);
		
		Map<String, Integer> collect = map.entrySet().stream().sorted(Map.Entry.<String,Integer>comparingByKey())
		.collect(Collectors.toMap(e->e.getKey(), e->e.getValue()));
		
		System.out.println(collect);
		
		
	}

}
