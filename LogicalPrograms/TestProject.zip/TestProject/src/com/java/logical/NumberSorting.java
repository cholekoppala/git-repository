package com.java.logical;

public class NumberSorting {

	public static void main(String[] args) {
		
		Integer[] arr= {10,5,29,98,3,2,39,79};
		int temp=0;
		
		for(int i=0;i<arr.length;i++) {
			
			for(int j=i+1;j<arr.length;j++) {
				
				if(arr[i]>arr[j]) {
					
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
					
				}
			}
			System.out.print(arr[i]+" ");
		}
	}
}
