package com.java.logical;

public class EachWordReverseString {

	public static void main(String[] args) {

		String str = "i love java programming";

		String[] words = str.split("\\s");
		String finalreverseString = "";

		for (int i = 0; i < words.length; i++) {
			String reverseWord = "";

			String word = words[i];

			for (int j = word.length() - 1; j >= 0; j--) {

				reverseWord = reverseWord + word.charAt(j);
			}

			finalreverseString = finalreverseString + reverseWord + " ";
		}
		System.out.println(finalreverseString);

	}

}
