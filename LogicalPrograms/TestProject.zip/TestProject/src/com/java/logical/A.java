package com.java.logical;

public class A extends Alphabets {

	public  void run() {

		System.out.println("A run()");
	}

	public static void main(String[] args) {
		
		Alphabets start=new A();
		
		start.run();
		

	}
}
