/**
 * 
 */
package com.java.logical;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class SingleTone {

	private static SingleTone obj = null;

	private SingleTone() {

	}

	public static SingleTone getForSingleTone() {

		if (obj == null) {

			obj = new SingleTone();

			return obj;
		} else {

			return obj;
		}
	}

	public static void main(String[] args) {

		SingleTone obj1 = getForSingleTone();
		SingleTone obj2 = getForSingleTone();
		SingleTone obj3 = getForSingleTone();

		System.out.println(obj1.hashCode());
		System.out.println(obj2.hashCode());
		System.out.println(obj3.hashCode());

	}
}
