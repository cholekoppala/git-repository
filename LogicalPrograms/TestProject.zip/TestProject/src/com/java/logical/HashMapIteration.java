package com.java.logical;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapIteration {
	
	public static void main(String[] args) {
		
		Map<String, Integer> map = Map.of("chole",87,"prasanth",76,"venkey",98,"sathish",96);
		map.forEach((k,v)->{
			
			System.out.println(k+" "+v);
		});
		
		Set<Entry<String,Integer>> set=map.entrySet();
		
		for (Entry<String, Integer> entry : set) {
			
			System.out.println(entry.getKey()+" "+entry.getValue());
			
		}
	}

}
