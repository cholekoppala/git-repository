package com.java.logical;

public class GivenNumberPrimeOrNot {

	public static void main(String[] args) {

		int num = 2;
		int count = 0;

		for (int i = 1; i <= num; i++) {

			if (num % i == 0) {

				count++;
			}
		}
		if (count == 2) {

			System.out.println("This is prime number=" + num);
		}

		else {

			System.out.println("This is not prime number=" + num);
		}
	}

}
