package com.java.logical;

public class Fibnocies {

	public static void main(String[] args) {

		int t1 = 0;
		int t2 = 1;

		for (int i = 0; i <= 5; i++) {

			System.out.print(t1 + " ");

			int temp = t1 + t2;
			t1 = t2;
			t2 = temp;
		}
      
	}

}
