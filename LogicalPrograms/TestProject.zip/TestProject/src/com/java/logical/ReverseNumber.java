package com.java.logical;

public class ReverseNumber {
	
	public static void main(String[] args) {
		
		int no=123456;
		String str=Integer.toString(no);
		String rev="";
		char[] ch=str.toCharArray();
		for(int i=ch.length-1;i>=0;i--) {
			
			rev=rev+ch[i];
		}
		System.out.println(rev);
	}

}
