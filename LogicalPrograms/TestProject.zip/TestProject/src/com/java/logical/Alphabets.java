package com.java.logical;

import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Alphabets {

	public static void main(String[] args) {
		
		String str="choleswaraiah";
		
		LinkedHashSet<Character> lh=new LinkedHashSet<>();
		//occurence
		LinkedHashMap<Character, Long> collect = str.chars().mapToObj(c->(char)c)
		.collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()));
		
		// duplicate characters
	str.chars().mapToObj(c->(char)c)
	.collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
	.entrySet().stream().filter(e->e.getValue()>1).
	forEach((data)->{
		
		//System.out.println(data.getKey());
	});
	
		// sorting
	String collect2 = str.chars().mapToObj(c->(char)c).sorted().map(Object::toString).collect(Collectors.joining());
	System.out.println(collect2);
	
	String collect3 = Stream.of(str).map(r->new StringBuilder(r).reverse()).collect(Collectors.joining());
	
	System.out.println(collect3);
	
int[] arr= {10,40,23,89,89,40,30};

Arrays.stream(arr).boxed().sorted(Comparator.reverseOrder()).forEach(System.out::println);





	
	
	
	
	
	//
       
	}
}
