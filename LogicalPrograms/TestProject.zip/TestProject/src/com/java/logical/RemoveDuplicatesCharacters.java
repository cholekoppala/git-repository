package com.java.logical;

public final class RemoveDuplicatesCharacters {

	public static void main(String[] args) {

		String str = "choleswaraiah";
		char[] ch = str.toCharArray();
		String ans = "";
		int i, j;
		for (i = 0; i < ch.length; i++) {
			for (j = 0; j < i; j++) {
				if (ch[i] == ch[j]) {
					break; // We are breaking here because this caharacter is already
				} // added to our answer because it was found earlier

			}
			if (i == j) { // The loop ends without breaking, it means this
				ans += ch[i]; // is the first occurence of this character in the string
			} // so we add this character to our answer
		}
		System.out.print(ans);
	}
}
