package com.java.logical;

public class MaxNumberArraysSort {

	public static void main(String[] args) {

		Integer[] arr = { 10, 78, 1, 87, 35, 25, 90 };
		int size = arr.length;
		System.out.println(size);
		int temp = 0;
		for (int i = 0; i < arr.length; i++) {

			for (int j = i + 1; j < arr.length; j++) {

				if (arr[i] >arr[j]) {

					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
		System.out.println("maxNumber=" + arr[size-1]);

	}

}
