package com.java.logical;

final class FinalCustom {

	final String panCardNumber;

	FinalCustom(String panCardNumber) {

		this.panCardNumber = panCardNumber;
	}

	public String getPanCardNumber() {

		return panCardNumber;
	}

	public static void main(String[] args) {

		FinalCustom finalCustom = new FinalCustom("ABC123");

		String panCardNo = finalCustom.getPanCardNumber();
		System.out.println(panCardNo);
	}
}
