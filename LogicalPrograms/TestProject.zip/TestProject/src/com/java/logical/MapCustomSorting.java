package com.java.logical;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

import com.java.test.Employee;

public class MapCustomSorting {

	public static void main(String[] args) {

		Employee e1 = new Employee(123, "chole", "Hyderabad", 99866.00);
		Employee e2 = new Employee(765, "venkatesh", "Benguluru", 543676.00);
		Employee e3 = new Employee(876, "prasanth", "chennai", 876565.00);

		Map<Integer, Employee> map = Map.of(12, e1, 14, e2, 11, e3);

		LinkedHashMap<Integer, Employee> collect = map.entrySet().stream()
				.sorted(Map.Entry.comparingByValue(Comparator.comparing(Employee::getEmpName)))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (s1, s2) -> s1, LinkedHashMap::new));
		System.out.println(collect);

		Map<Integer, Employee> collect2 = map.entrySet().stream().sorted(Map.Entry.comparingByKey())
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

		System.out.println(collect2);
		
		
		
		
		
		
	}

}
