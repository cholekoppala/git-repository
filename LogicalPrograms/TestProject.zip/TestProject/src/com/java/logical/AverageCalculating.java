package com.java.logical;

import java.util.List;
import java.util.stream.Collectors;

import com.java.classes.Person;

public class AverageCalculating {

	public static void averageCalculating() {

		Integer[] arr = { 10, 20, 30, 40, 50 };
		int noofelements = arr.length;
		int sumofelements = 0;
		double average = 0;
		for (int i = 0; i < arr.length; i++) {

			sumofelements = sumofelements + arr[i];

		}
		average = sumofelements / noofelements;
		System.out.println(average);
	}

	public static void main(String[] args) {

		Person p1 = new Person("chole", 29, "Hyd");
		Person p2 = new Person("siva", 26, "chennai");
		Person p3 = new Person("guru", 28, "banglore");
		Person p4 = new Person("suresh", 25, "mumbai");

		List<Person> list = List.of(p1, p2, p3, p4);

		Double average = list.stream().collect(Collectors.averagingInt(Person::getAge));

		System.out.println(average);

	}

}
