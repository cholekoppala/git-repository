package com.java.logical;

import java.util.Arrays;

public class StringDataSorting {
	
	public static void main(String[] args) {
		
		String str="choleswaraiah";
		
		char[] ch=str.toCharArray();
		
		Arrays.sort(ch);
		String sort="";
		for (char c : ch) {
			
			sort=sort+c;
		}
		System.out.println(sort);
	}

}
