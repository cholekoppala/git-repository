package com.java.logical;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class HashMapConcurrentModificationException {

	public static void main(String[] args) {

		 HashMap<String,Integer> hm=new HashMap<>();
		//Map<String, Integer> hm = new ConcurrentHashMap();

		hm.put("A", 10);
		hm.put("B", 20);
		hm.put("C", 30);
		hm.put("D", 40);

		System.out.println(hm);

		Iterator<Entry<String, Integer>> iterator = hm.entrySet().iterator();

		while (iterator.hasNext()) {

			Entry<String, Integer> key = iterator.next();
			if (key.getKey().equals("A")) {

				//hm.replace("A", 10, 500);
				hm.remove("A");
			}
		}
		System.out.println(hm);
	}

}
