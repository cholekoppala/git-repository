package com.java.logical;

public class StringDisplayDuplicates {

	public static void dup() {
		
		  String str = "choleswaraiah";
	       char[] ch= str.toCharArray();
	       
	       int i,j;
	       
	       String res="";
	       
	       for(i=0;i<ch.length;i++) {
	    	   
	    	   for(j=0;j<i;j++) {
	    		   
	    		   if(ch[i]==ch[j]) {
	    			   
	    			   break;
	    		   }
	    	   }
	    	   if(i==j) {
	    		   
	    		   System.out.print(ch[i]);
	    	   }
	       }
	}
	public static void main(String[] args) {

		String str = "choleswaraiah";

		char[] ch = str.toCharArray();

		for (int i = 0; i < ch.length; i++) {

			for (int j = i + 1; j < ch.length; j++) {

				if (ch[i] == ch[j]) {

					//System.out.print(ch[i] + " ");
					break;
				}
				else {
					
					System.out.print(ch[i]+"");
				}
			}

		}
	}

}
