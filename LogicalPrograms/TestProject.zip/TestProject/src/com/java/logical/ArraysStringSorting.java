package com.java.logical;

public class ArraysStringSorting {

	public static void main(String[] args) {

		String str[] = { "sathish", "chole", "venkey", "prasanth", "guru", "siva", "muini" };
		String temp="";
		for(int i=0;i<str.length;i++) {
			
			for(int j=i+1;j<str.length;j++) {
				
				if(str[i].compareTo(str[j])>0) {
					
					temp=str[i];
					str[i]=str[j];
					str[j]=temp;
				}
			}
			System.out.print(str[i]+" ");
		}

	}
}
