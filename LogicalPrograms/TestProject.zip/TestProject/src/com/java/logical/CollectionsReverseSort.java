package com.java.logical;

import java.util.Arrays;
import java.util.Collections;

public class CollectionsReverseSort {
	
	public static void main(String[] args) {
		
		Integer[] arr= {20,30,10,50,87,6,88};
		
		//Arrays.sort(arr,Collections.reverseOrder());
		
		Collections.sort(Arrays.asList(arr),Collections.reverseOrder());
		
		for (Integer sort : arr) {
			
			System.out.print(sort+" ");
		}
		
	}

}
