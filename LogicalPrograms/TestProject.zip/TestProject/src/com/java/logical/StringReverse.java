package com.java.logical;

public class StringReverse {
	
	public static void main(String[] args) {
		
		String str="choleswaraiah";
		char[] len = str.toCharArray();
		System.out.println(len.length);
		String rev="";
		
		for(int i=len.length-1;i>=0;i--) {
			
			rev=rev+len[i];
		}
		System.out.println(rev);
	}

}
