package com.java.logical;

public class Test {

	public static void twopointer(int[] arr, int key) {

	
		for(int i=0;i<arr.length-2;i++) {
			
			for(int j=i+1;j<arr.length-1;j++) {
				
				for(int k=j+1;j<arr.length;j++) {
					
					if(arr[i]+arr[j]+arr[k]==key) {
						
						System.out.println(arr[i]+","+arr[j]+","+arr[k]+"="+key);
					}
				}
			}
		}
		
		
	}

	public static void main(String[] args) {

        int arr[] = { 1, 4, 45, 6, 10, 8 };
        int key = 22;
		twopointer(arr, key);
	}

}
