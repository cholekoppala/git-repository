package com.java.datastructure;

class LinkedList {

	static Node head;

	public void insert(int data) {

		Node node = new Node();
		node.data = data;
		node.next = null;

		if (head == null) {

			head = node;
		} else {

			Node n = head;

			while (n.next != null) {

				n = n.next;
			}
			n.next = node;
		}
	}

	public void deleteAt(int index) {

		if (index == 0) {

			head = head.next;
		} else {

			Node n = head;
			Node n1 = null;
			for (int i = 0; i < index - 1; i++) {

				n=n.next;
			}
			n1=n.next;
			n.next=n1.next;
		}
	}
	public Node reverseMyOwn() {
		Node node = head;
		Node prev = null;
		Node current = node;
		Node next = null;

		while (current != null) {

			next = current.next;
			current.next = prev;
			prev = current;
			current = next;
		}
		node = prev;
		return node;
	}

	public void show() {

		Node res = head;

		while (res.next != null) {

			System.out.println(res.data);
			res = res.next;
		}
		System.out.println(res.data);
	}
	public static void main(String[] args) {
		
		LinkedList linkedList = new LinkedList();
		
		linkedList.insert(10);
		linkedList.insert(20);
		linkedList.insert(30);
		linkedList.insert(40);
		

		head=linkedList.reverseMyOwn();
		
		linkedList.show();
	}
}