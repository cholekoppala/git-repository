package com.java.datastructure;

public class Node {
	
	int data;
	Node next;

}
