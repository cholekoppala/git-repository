package com.java.datastructure;

public class App {
	
	public static void main(String[] args) {
		
		LinkedList ls = new LinkedList();
		ls.insert(10);
		ls.insert(20);
		ls.insert(30);
		ls.insert(40);
		ls.deleteAt(0);
		ls.show();
        
	}

}
