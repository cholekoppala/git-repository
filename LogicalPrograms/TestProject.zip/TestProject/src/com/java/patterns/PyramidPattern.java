package com.java.patterns;

public class PyramidPattern {

	public static void main(String[] args) {
		
	

		int num = 5;
		for (int i = 1; i <= num; i++) {

			System.out.println(" ");

			for (int j = 1; j <= i; j++) {
				
				//System.out.print(+i+" ");
				System.out.print("* ");


			}
          System.out.println();
		}
	}

}
