package com.java.test;

public class ReverseString {

	public static void main(String[] args) {

		String str = "choleswaraiah";

		
	}

}
