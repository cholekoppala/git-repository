package com.java.test;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class MinMaxJava {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(10, 78, 90, 10, 54);

		List<String> asList = Arrays.asList("A", "B", "C", "D", "E", "Z", "W");
		Comparator<String> comparing2 = Comparator.comparing(String::valueOf);

		list.stream().max(Comparator.comparing(Integer::intValue)).get();

		System.out.println();

	}

}
