package com.java.test;

import java.util.Arrays;
import java.util.List;

public class FindFirstAndFindAny {
	
	public static void main(String[] args) {
		
	    List<String> list = Arrays.asList("A","B","C","D");
	    String string = list.stream().findFirst().get();
	    String string2 = list.stream().findAny().get();
	    List<Integer> list1 = Arrays.asList(1, 2, 3, 4, 5);
	    Integer integer = list1.stream().filter(n->n<4).findAny().get();
	    
        List<String> list2 = Arrays.asList("node", "java", "python", "ruby");

        String result = list2.stream()
                .filter(x -> !x.equalsIgnoreCase("node"))
                .findFirst().get();


	    System.out.println(string);
	    System.out.println(string2);
	    System.out.println(integer);
	    System.out.println(result);
	    

	}

}
