package com.java.test;

public class Employee {

	
		
		public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
		public Employee(Integer empId, String empName, String empAddr, Double empSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empAddr = empAddr;
		this.empSal = empSal;
	}
		private Integer empId;
		private String empName;
		private String empAddr;
		private Double empSal;
		public Integer getEmpId() {
			return empId;
		}
		public void setEmpId(Integer empId) {
			this.empId = empId;
		}
		public String getEmpName() {
			return empName;
		}
		public void setEmpName(String empName) {
			this.empName = empName;
		}
		public String getEmpAddr() {
			return empAddr;
		}
		public void setEmpAddr(String empAddr) {
			this.empAddr = empAddr;
		}
		public Double getEmpSal() {
			return empSal;
		}
		public void setEmpSal(Double empSal) {
			this.empSal = empSal;
		}
		@Override
		public String toString() {
			return "Employee [empId=" + empId + ", empName=" + empName + ", empAddr=" + empAddr + ", empSal=" + empSal
					+ "]";
		}
		
		
	
}
