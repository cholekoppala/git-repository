package com.java.test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class PeekAndParallelStream {
	
	public static void main(String[] args) {
		
		//debug purpose
        List<Integer> numbers = Arrays.asList(1,2,3,4,5,6,7);
 
        // Stream.peek()
        numbers // data source
        .stream() // get Stream
        .filter(res->!res.equals(3))
        .peek(System.out::println)
        .collect(Collectors.toList());

	}

}
