package com.java.test;

import java.util.Arrays;

public class TestSum {
	
	public static void main(String[] args) {
		
		  int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		  System.out.println(Arrays.stream(numbers).reduce(Integer::min));
		  System.out.println(Arrays.stream(numbers).reduce(Integer::sum));
		  System.out.println(Arrays.stream(numbers).reduce(0,(a,b)->a+b));



		
	}

}
