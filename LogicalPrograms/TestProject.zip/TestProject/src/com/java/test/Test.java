package com.java.test;

import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Test {

	public static void main(String[] args) {

		Employee e1 = new Employee(123, "chole", "Hyderabad", 99866.00);
		Employee e2 = new Employee(765, "venkatesh", "Benguluru", 543676.00);
		Employee e3 = new Employee(11, "ajay", "chennai", 876565.00);

		List<Employee> list = Arrays.asList(e1,e2,e3);
		
	Map<Integer,String> mp=	list.stream()
		.collect(Collectors.toMap(Employee::getEmpId, Employee::getEmpAddr));
	
	Map<String,List<Employee>> ls=list.stream()
	.collect(Collectors.groupingBy(Employee::getEmpAddr));
		
	

	}

}
