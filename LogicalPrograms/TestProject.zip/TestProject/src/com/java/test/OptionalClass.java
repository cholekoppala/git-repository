package com.java.test;

import java.util.Optional;

public class OptionalClass {
	
	public static void main(String[] args) {
		
		String str[] =new String[10];
		str[5]="A";
		
		Optional<String> value = Optional.ofNullable(str[5]);
		
		if(value.isPresent()) {
			
			String res = str[5].toLowerCase();
			System.out.println(res);


		}
		else {
			
			System.out.println("value is not present");
		}
	}

}
