package com.java.test;

import java.util.Arrays;

public class ReduceExample {

	public static void main(String[] args) {

		int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		String[] strings = { "a", "b", "c", "d", "e" };

		System.out.println(Arrays.stream(numbers).reduce(0, (a, b) -> a + b));
		System.out.println(Arrays.stream(numbers).reduce(Integer::sum));
		System.out.println(Arrays.stream(numbers).reduce(Integer::max));
		System.out.println(Arrays.stream(numbers).reduce(1, (a, b) -> a < b ? a : b));
		String reduce = Arrays.stream(strings).reduce("", (a, b) -> a + "|" + b);
		  String join = String.join("|", strings);

		System.out.println(reduce);
		System.out.println(join);


	}

	
}
