package com.java.test;

import java.util.Arrays;

public class LimitAndSkip {
	
	public static void main(String[] args) {
		
		int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
//	Arrays.stream(numbers).limit(3).forEach(s->System.out.println(s));
		Arrays.stream(numbers).skip(3).forEach(s->System.out.println(s));

		
	}

}

