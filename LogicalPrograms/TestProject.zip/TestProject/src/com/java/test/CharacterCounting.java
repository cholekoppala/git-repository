package com.java.test;

import java.util.Map;
import java.util.stream.Collectors;

public class CharacterCounting {
	
	public static void main(String[] args) {
		
		String str="choleswaraiah";
		
		Map<Character, Long> count = str.chars().mapToObj(c->(char)c).
				collect(Collectors.groupingBy(c->c,Collectors.counting()));
		
		System.out.println(count);
	}

}
