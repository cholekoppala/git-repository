package com.java.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class App {

	public static void main(String[] args) {
		
		Employee e1 = new Employee(123, "chole", "Hyd", 90087.00);
		Employee e2 = new Employee(153, "satheesh", "chennai", 78866.00);
		Employee e3 = new Employee(165, "prasanth", "Banglore", 98766.00);
		Employee e4 = new Employee(165, "prasanth", "Hyd", 98766.00);

		
		List<Employee> list = Arrays.asList(e1,e2,e3,e4);
		List<String> res=new ArrayList<>();
		list.stream().filter(ls->ls.getEmpAddr().equals("Hyd"))
		.map(r->res.add(r.getEmpName()))
		.collect(Collectors.toList());
		
		System.out.println(res);
		
		
		
	}
}


