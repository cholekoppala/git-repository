package com.java.test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GroupingByEmployees {
	
	public static void main(String[] args) {
		
		Employee e1 = new Employee(123, "chole", "Hyd", 90087.00);
		Employee e2 = new Employee(153, "satheesh", "chennai", 78866.00);
		Employee e3 = new Employee(165, "prasanth", "Banglore", 98766.00);
		
		List<Employee> list = Arrays.asList(e1,e2,e3);
		
		Map<Integer, String> listToMapConv = list.stream().collect(Collectors.toMap(Employee::getEmpId, Employee::getEmpAddr));
		
		Map<String,List<Employee>> groupByEmpAddr=	list.stream()
				.collect(Collectors.groupingBy(Employee::getEmpAddr));
		
		System.out.println(listToMapConv);
		System.out.println(groupByEmpAddr);

	}

}
