package com.java.practice;

public class Node {

	private int data;
	Node nextVal;
	
	

}
