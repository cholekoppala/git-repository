package com.java.practice;

import java.util.Comparator;
import java.util.stream.Collectors;

public class CustomLinkedList {

	public static void main(String[] args) {

		int[] arr = { 1, 2, 3, 4, 5, 6 };
		
		
		// op:{4,5,6,1,2,3}

		// array left shift and right shift
		// linked list internal implementation add and delete
		// java8 groupingby department max salary wise average salary

	}

}
