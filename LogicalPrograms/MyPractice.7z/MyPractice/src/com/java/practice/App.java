package com.java.practice;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class App {
	
	public static void main(String[] args) {
		
	//IntStream.range(1, 6).mapToObj(1->i).
//	forEach(System.out::println);



				// .mapToObj(i -> i).collect(Collectors.toList());

				//l.forEach(System.out::println);







 
 
 




		
				
		

		
	}

}
