package com.java.test;

import java.util.Arrays;

public class ArraysAverage {

	public static void main(String[] args) {

		int[] arr = { 20, 56, 10, 45, 87, 30 };

		double average = Arrays.stream(arr).average().getAsDouble();

		System.out.println(average);

	}

}
