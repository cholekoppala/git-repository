package com.java.test;

public class SingleDigitSum {

	static int singleDigit(int n) {

		if (n == 0)

			return 0;

		return (n % 9 == 0) ? 9 : (n % 9);
	}

	public static void main(String[] args) {

		System.out.println(singleDigit(9092));

	}

}
