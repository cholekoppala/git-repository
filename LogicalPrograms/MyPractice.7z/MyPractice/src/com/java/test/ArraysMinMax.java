package com.java.test;

import java.util.Arrays;

public class ArraysMinMax {
	
	public static void main(String[] args) {
		
		int[] arr = { 20, 56, 10, 45, 87, 30 };
		
		int max = Arrays.stream(arr).max().getAsInt();
		int min = Arrays.stream(arr).min().getAsInt();

	}

}
