package com.java.test;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FrequencyFindoutList {

	public static void main(String[] args) {

		List<String> list = List.of("hello", "hello", "bye", "hi");

		Map<String, Long> collect = list.stream().collect(Collectors.groupingBy(c -> c, Collectors.counting()));

		System.out.println(collect);
	}

}
