package com.java.test;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EachWordReverse {
	
	
	public static void eachWordReverse(String str) {
		
		String[] words = str.split(" ");

		String finalrev = "";

		for (int i = 0; i < words.length; i++) {

			String rev = "";
			String word = words[i];

			for (int j = word.length() - 1; j >= 0; j--) {

				rev = rev + word.charAt(j);
			}

			finalrev = finalrev + rev+" ";

		}
		System.out.println(finalrev);
	}
	
	public static void main(String[] args) {
		
		String str="i love you java programming";
		
		String reverse = Stream.of(str.split(" ")).map(st->new StringBuilder(st).reverse())
		.collect(Collectors.joining(" "));
		
		System.out.println(reverse);
		
		
	}

}
