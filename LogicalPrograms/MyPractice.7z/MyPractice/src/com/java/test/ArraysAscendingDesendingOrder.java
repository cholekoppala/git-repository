package com.java.test;

import java.util.Arrays;
import java.util.Collections;
import java.util.stream.Stream;

public class ArraysAscendingDesendingOrder {
	
	public static void main(String[] args) {
		
		int[] arr = { 20, 56, 10, 45, 87, 30 };
		
		int[] ascend = Arrays.stream(arr).sorted().toArray();
		
		Stream.of(arr).sorted(Collections.reverseOrder());

	}

}
