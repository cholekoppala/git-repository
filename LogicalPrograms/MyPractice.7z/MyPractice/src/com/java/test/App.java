package com.java.test;

class App {

	public static void main(String[] args) {

		String str="choleswaraiah";
		String uinq="";
		String dup="";
		char[] ch=str.toCharArray();
		int i,j;
		for( i=0;i<ch.length;i++) {
			
			for( j=0;j<i;j++) {
				
				if(ch[i]==ch[j]) {
					
					break;
				}
			}
			if(i==j) {
				
				uinq=uinq+ch[i];
				
			}
			else {
				
				dup=dup+ch[i];
			}
		}
        System.out.println(uinq);
        System.out.println(dup);
	}
}
