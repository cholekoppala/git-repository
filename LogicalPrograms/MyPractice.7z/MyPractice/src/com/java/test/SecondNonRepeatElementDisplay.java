package com.java.test;

import java.util.stream.Collectors;

public class SecondNonRepeatElementDisplay {
	
	public static void main(String[] args) {
		
		String str="taeeterd";
		
		 char charAt = str.chars().mapToObj(c->(char)c).collect(Collectors.groupingBy(c->c,Collectors.counting()))
        .entrySet()
        .stream().filter(e->e.getValue()==1)
        .map(x->x.getKey())
        .map(Object::toString).collect(Collectors.joining())
       // .substring(1,2);
		 .charAt(2);
        
      //  .findFirst().get().getKey();
		
		//System.out.println(key);
		
		System.out.println(charAt);
		
	}

}
