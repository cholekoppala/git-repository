/**
 * 
 */
package com.java.serilization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class App {
	
	
	public static void callSerilization() throws IOException {
		
		// serilization

		FileOutputStream fileOutputStream = new FileOutputStream("customer.ser");
		ObjectOutputStream outputStream = new ObjectOutputStream(fileOutputStream);

		Customer obj = new Customer();
		obj.setCustId(123);
		obj.setCustName("chole");
		obj.setCusAddr("Hyd");

		outputStream.writeObject(obj);

	}
	
	public static void callDesirilazation() throws IOException, ClassNotFoundException {
		
		// desirlization

		FileInputStream fileInputStream = new FileInputStream("customer.ser");

		ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);

		Customer cobj = (Customer) objectInputStream.readObject();

		System.out.println(cobj);

	}

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
   // callSerilization();
     
     callDesirilazation();
	
	}
}
