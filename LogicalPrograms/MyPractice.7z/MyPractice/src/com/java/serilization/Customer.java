/**
 * 
 */
package com.java.serilization;

import java.io.Serializable;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class Customer implements Serializable {

	/**
	 * 
	 */
	//private static final long serialVersionUID = 572203431090225371L;

	private Integer custId;
	private String custName;
	private String cusAddr;
	private String product;

	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(Integer custId, String custName, String cusAddr) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.cusAddr = cusAddr;
	}

	public Integer getCustId() {
		return custId;
	}

	public void setCustId(Integer custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCusAddr() {
		return cusAddr;
	}

	public void setCusAddr(String cusAddr) {
		this.cusAddr = cusAddr;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", cusAddr=" + cusAddr + "]";
	}

}
