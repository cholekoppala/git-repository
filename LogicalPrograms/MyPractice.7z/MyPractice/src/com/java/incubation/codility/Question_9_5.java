package com.java.incubation.codility;
public class Question_9_5 implements AnInterface{

public static void main(String[] args){

AnInterface a=()->aMethod();
System.out.println(a.anotherMethod());

}

@Override
public int anotherMethod() {
	// TODO Auto-generated method stub
	return 0;
}

}

2//lamda expression dont return any value
