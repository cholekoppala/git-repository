package com.java.incubation.codility;

import java.util.stream.Stream;

public class Question10 {
	
	public static void main(String[] args) {
		
		Stream<String> s=Stream.generate(()->"melow");
		boolean match=s.allMatch(String::isEmpty);
	}

}
