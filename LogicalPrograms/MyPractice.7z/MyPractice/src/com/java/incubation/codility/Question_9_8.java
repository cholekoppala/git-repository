package com.java.incubation.codility;

interface X {
	int test(int i);
}

public class Question_9_8 {

	int i = 0;

	public static void main(String[] args)

	{

		X x = i -> i * 2;
		System.out.println(x.test(3));

	}

}