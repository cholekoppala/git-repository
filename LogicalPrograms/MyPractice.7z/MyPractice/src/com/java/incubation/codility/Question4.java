/**
 * 
 */
package com.java.incubation.codility;

import java.util.stream.Stream;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class Question4 {
	
	public static void main(String[] args) {
		
		Stream<String> stream=Stream.iterate("",(s)->s+"1");
		System.out.println(stream.limit(2).map(x->x+"2"));

	}

}
