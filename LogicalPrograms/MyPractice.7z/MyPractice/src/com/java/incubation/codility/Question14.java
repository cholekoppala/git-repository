package com.java.incubation.codility;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Question14 {
	
	public static void main(String[] args) {
		
		List<Integer> ls=IntStream.range(1,6)
				.mapToObj(i->i).collect(Collectors.toList());
				
				ls.forEach(System.out::println);

			IntStream.range(1,6).forEach(System.out::println);
	}

}
