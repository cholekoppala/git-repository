package com.java.incubation.codility;

interface AnInterface {

	default int aMethod() {

		return 0;

	}

	int anotherMethod();
}