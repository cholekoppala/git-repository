/**
 * 
 */
package com.java.incubation.programs;

import java.util.Arrays;
import java.util.Collections;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class SecondLargestElement {
	
	public static int secondLargest(Integer[] arr) {
		
		Arrays.sort(arr,Collections.reverseOrder());
		
		for(int i=0;i<arr.length;i++) {
			
			if(arr[i]!=arr[0]) {
				
				System.out.println(arr[i]);
				return arr[i];
			}
		}
		return -1;
	}
	
	public static void main(String[] args) {
		
        Integer arr[] = {12, 35, 1, 10, 34, 1};
        
        secondLargest(arr);
        

	}

}
