/**
 * 
 */
package com.java.incubation.programs;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class FindThripleSum {
//https://www.geeksforgeeks.org/find-a-triplet-that-sum-to-a-given-value/
	public static boolean thripleSum(int[] arr, int len, int sum) {

		for (int i = 0; i < len - 2; i++) {

			for (int j = i + 1; j < len - 1; j++) {

				for (int k = 0; k < len; k++) {

					if (arr[i] + arr[j] + arr[k] == sum) {

						System.out.println("triple sum::" + arr[i] + " " + arr[j] + " " + arr[k]);
						return true;
					}
				}
			}
		}

		return false;
	}

	public static void main(String[] args) {

		int A[] = { 1, 4, 45, 6, 10, 8 };
		int sum = 22;

		int len = A.length;
		
		thripleSum(A, len, sum);
	}

}
