/**
 * 
 */
package com.java.incubation.programs;

import java.util.Stack;

/**
 * @author Koppala_Choleswaraia
 *
 */
//https://www.youtube.com/watch?v=u3paQa8KXu0
public class EvaluationPostfrix {

	public static int getEvaluationPostfrix(String exp) {

		Stack<Integer> stack = new Stack<Integer>();

		for (int i = 0; i < exp.length(); i++) {

			char c = exp.charAt(i);

			if (Character.isDigit(c)) {

				stack.push((int)c - '0');

			} else {

				int a = stack.pop();
				Integer b = stack.pop();

				switch (c) {

				case '+':
					stack.push(b+a);
					break;

				case '-':
					stack.push(b-a);
					break;

				case '/':
					stack.push(b/a);
					break;

				case '*':
					stack.push(b*a);
					break;
				}
			}

		}

		return stack.pop();
	}

	public static void main(String[] args) {
		
        String exp = "231*+9-";
       int evaluationPostfrix = getEvaluationPostfrix(exp);
       System.out.println(evaluationPostfrix);

	}

}
