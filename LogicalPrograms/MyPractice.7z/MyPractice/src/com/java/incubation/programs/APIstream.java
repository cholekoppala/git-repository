package com.java.incubation.programs;
import java.util.stream.Stream;   
import java.util.Arrays;   
import java.io.*;   
public class APIstream  
{
    public static <T> Integer[] mergeArray(T[] arr1, T[] arr2)   
    {   
        return Stream.of(arr1, arr2).flatMap(Stream::of).toArray(Integer[]::new);   
    }   
    public static void main (String[] args)    
    {   
        Integer[] arr1 = new Integer[]{1,2,3,4,5};
        Integer[] arr2 = new Integer[]{6,7,8,9}; 
        
        Integer[] array = Stream.of(arr1,arr2).flatMap(Stream::of).toArray(Integer[]::new);
        System.out.println(Arrays.toString(array));
        Integer[] arr3 = mergeArray(arr1,arr2); 
        System.out.println("Array after merging: "+ Arrays.toString(arr3));   
    }   
}  