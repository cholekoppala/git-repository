/**
 * 
 */
package com.java.incubation.programs;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class CustomLinkedList {

	 public Node head;

	public Node insertData(Integer data) {

		if(data==null) {
			
			return null;
		}
		Node node = new Node();
		node.data = data;
		node.next = null;

		if (head == null) {

			head = node;
		} else {

			Node n = head;
			while (n.next != null) {

				n = n.next;

			}
			n.next = node;
		}
		return node;
	}
	
	public boolean insert(Integer data) {

		if(data==null) {
			
			return false;
		}
		Node node = new Node();
		node.data = data;
		node.next = null;

		if (head == null) {

			head = node;
		} else {

			Node n = head;
			while (n.next != null) {

				n = n.next;

			}
			n.next = node;
		}
		return true;
	}
	
	Node rotateRight(Node head, int k) {
	    if (head == null || head.next == null) return head;
	    for (int i = 0; i < k; i++) {
	      Node temp = head;
	      while (temp.next.next != null) temp = temp.next;
	      Node end = temp.next;
	      temp.next = null;
	      end.next = head;
	      head = end;
	    }
	    return head;
	  }
	
	public Node insetDataLast(int data) {
		
		Node node = new Node();
		node.data = data;
		node.next = null;

		if (head == null) {

			head = node;
		} else {

			Node n = head;
            head = node; 
            head.next=n;
		}
		return node;
	}
	
	public Node middleDeletion(Node head) {
		 
	        // Base cases 
	        if (head == null) 
	            return null; 
	        if (head.next == null) { 
	            return null; 
	        } 
	        Node copyHead = head; 
	  
	        // Find the count of nodes 
	        int count = countOfNodes(head); 
	  
	        // Find the middle node 
	        int mid = count / 2; 
	  
	        // Delete the middle node 
	        while (mid-- > 1) { 
	            head = head.next; 
	        } 
	  
	        // Delete the middle node 
	        head.next = head.next.next; 
	  
	        return copyHead; 
	    } 
	 // count of nodes 
    int countOfNodes(Node head) 
    { 
        int count = 0; 
        while (head != null) { 
            head = head.next; 
            count++; 
        } 
        return count; 
    } 
  

	public Node reverseLinkedList() {

		Node node = head;
		Node prev = null;
		Node current = node;
		Node next = null;
		while (current != null) {

			next = current.next;
			current.next = prev;
			prev = current;
			current = next;

		}
		node = prev;
		return node;
	}
	public boolean middleDeletionAtElement(Node head,Integer element) {
		 
        // Base cases 
        if (head == null || 1>=element) 
            return false; 
        if (head.next == null) { 
            return false; 
        } 
        Node copyHead = head; 
  
        // Find the count of nodes 
        int count = countOfNodes(head); 
  
        // Find the middle node 
        int mid = count / 2; 
  
        // Delete the middle node 
        while (mid-- > 1) { 
            head = head.next; 
        } 
  
        // Delete the middle node 
        head.next = head.next.next; 
  
        return true; 
    } 
	public boolean reverseLinked(Integer element,Node head) {

		if(element==null || head==null) {
			return false;
		}
		Node node = head;
		Node prev = null;
		Node current = node;
		Node next = null;
		if(1>=element) {
			
			return false;
		}
		if(1<element) {
		while (current != null) {

			next = current.next;
			current.next = prev;
			prev = current;
			current = next;

		}
		}
		node = prev;
		return true;
	}

	public void printData() {

		Node res = head;

		while (res.next != null) {

			System.out.println(res.data);
			res = res.next;
		}
		System.out.println(res.data);

	}
	
	public void printList(Node head) {
	    while (head.next != null) {
	      System.out.print(head.data + "->");
	      head = head.next;
	    }
	    System.out.println(head.data);

	  }


	public void deleteElementAt(int index) {

		
		if (index == 0) {

			head = head.next;
		} else {

			Node n = head;
			Node n1 = null;
			for (int i = 0; i < index - 1; i++) {

				n=n.next;
			}
			n1=n.next;
			n.next=n1.next;
		}
		
		
	}
	
	public boolean deleteElementAtIndex(Integer index,Node head) {

		if(index==0 || head==null) {
			
			return false;
		}
		if (index == 0) {

			head = head.next;
		} else {

			Node n = head;
			Node n1 = null;
			for (int i = 0; i < index - 1; i++) {

				n=n.next;
			}
			n1=n.next;
			n.next=n1.next;
		}
		
		return true;
	}

	public static void main(String[] args) {

		CustomLinkedList cl = new CustomLinkedList();
		
		cl.insert(10);
		cl.insert(20);
		cl.insert(30);
		
//		cl.head=cl.insertData(10);
//		cl.head.next=cl.insertData(20);
//		cl.head.next.next=cl.insertData(30);
//		cl.head.next.next.next=cl.insertData(40);
//		cl.head.next.next.next.next=cl.insertData(50);
		
		//int k = 4;
	   // Node newHead = cl.rotateRight(cl.head, k);
	 //  cl. printList(newHead);
		
//		cl.insetDataLast(10);
//		cl.insetDataLast(20);
//		cl.insetDataLast(30);
//		cl.insetDataLast(40);

		//cl.head = cl.reverseLinkedList();
		//cl.deleteElementAt(4);
		//cl.middleDeletion(cl.head);
		cl.printData();
	}

}
