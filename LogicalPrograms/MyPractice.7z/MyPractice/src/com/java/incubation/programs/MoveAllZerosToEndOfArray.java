/**
 * 
 */
package com.java.incubation.programs;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class MoveAllZerosToEndOfArray {

	public static void moveAllzerosToEnd(int[] arr, int n) {

		int count = 0;
		for (int i = 0; i < n; i++) {
			if (arr[i] != 0) {
				arr[count++] = arr[i];
			}
		}
		while (count < n)
			arr[count++] = 0;
	}

	public static void display(int[] arr) {

		int temp = 0;

		for (int i = 0; i < arr.length; i++) {

			for (int j = i + 1; j < arr.length; j++) {

				if (arr[i]!=0) {

					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}

		for (int i = arr.length - 1; i >= 0; i--) {

			System.out.print(arr[i] + " ");
		}
	}

	public static void main(String[] args) {

		int[] arr = { 1, 2, 0, 4, 3, 0, 5, 0 };
		int n = arr.length;
		//moveAllzerosToEnd(arr, n);
		display(arr);
	//	System.out.println(Arrays.toString(arr));

	}

}
