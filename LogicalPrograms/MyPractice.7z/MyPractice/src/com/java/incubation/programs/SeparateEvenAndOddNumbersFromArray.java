/**
 * 
 */
package com.java.incubation.programs;

import java.util.Arrays;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class SeparateEvenAndOddNumbersFromArray {
	
	public static int[] separateEvenAndOddNumber(int[] arr) {
		
		int left=0;
		int right=arr.length-1;
		
		for(int i=0;i<arr.length;i++) {
			
			while(arr[left]%2==0) {
				
				left++;
			}
			
			while(arr[right]%2==1) {
				
				right--;
			}
			if(left<right) {
				
				int temp=arr[left];
				arr[left]=arr[right];
				arr[right]=temp;
			}
		}
		return arr;
	}
	static void rearrangeEvenAndOdd(int arr[])
    {
        // variables
        int j = -1,temp;
     
        // quick sort method
        for (int i = 0; i < arr.length; i++) {
     
            // if array of element
            // is odd then swap
            if (arr[i] % 2 == 0) {
     
                // increment j by one
                j++;
     
                // swap the element
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
            System.out.print(arr[i]+" ");
        }
    }
	
	
	static void arrayEvenAndOdd(int arr[], int n)
    {

        int i = -1, j = 0;
        while (j != n) {
            if (arr[j] % 2 == 0) {
                i++;

                // Swapping even and
                // odd numbers
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
            j++;
        }
    }
	public static void main(String[] args) {
		
        int arr[] = {1, 3, 2, 4, 7, 6, 9, 10};
        
        int[] separateEvenAndOddNumber = separateEvenAndOddNumber(arr);
         System.out.println(Arrays.toString(separateEvenAndOddNumber));
		rearrangeEvenAndOdd(arr);
	}

}
