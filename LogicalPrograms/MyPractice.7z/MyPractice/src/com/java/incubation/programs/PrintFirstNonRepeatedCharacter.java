/**
 * 
 */
package com.java.incubation.programs;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class PrintFirstNonRepeatedCharacter {

	@SuppressWarnings("unlikely-arg-type")
	private static void printFirstNonRepeatedCharacter(String str) {
		// Calculating frequencies using LinkedHashMap
		Map<Character, Integer> freq = new LinkedHashMap<>();
		for (char c : str.toCharArray()) {
			freq.put(c, freq.getOrDefault(c, 0) + 1);
		}
		System.out.println(freq);

		// Traverse the string
		for (char c : str.toCharArray()) {
			if (freq.get(c) == 1) {
				
				System.out.println("First non-repeating character is " + c);
				return;
			}
		}
	}

	public static void main(String[] args) {

		String str = "hello";

		printFirstNonRepeatedCharacter(str);
		
		String string = str.chars().mapToObj(c->(char)c).collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
		.entrySet().stream().filter(ke->1==ke.getValue())
		.map(key->key.getKey().toString()).findFirst().get();

	}

}
