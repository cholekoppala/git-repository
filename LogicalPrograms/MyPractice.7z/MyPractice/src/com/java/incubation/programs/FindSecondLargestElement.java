/**
 * 
 */
package com.java.incubation.programs;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class FindSecondLargestElement {

	public static void findSecondLargestElement(int[] arr) {

		int first = Integer.MIN_VALUE;
		int second = Integer.MIN_VALUE;
		int third = Integer.MIN_VALUE;

		for (int i = 0; i < arr.length; i++) {

			int current = arr[i];

			if (first < current) {

				third = second;
				second = first;
				first = current;
			}

			else if (second < current) {

				third=second;
				second = current;

			}
			else if (third < current) {
				third = current;
			}
		}
		System.out.println(first+","+second+","+third);
	}

	public static void main(String[] args) {

		int[] arr = new int[] { 6, 8, 1, 9, 2, 1, 10 };

		findSecondLargestElement(arr);

	}

}
