/**
 * 
 */
package com.java.incubation.programs;

/**
 * @author Koppala_Choleswaraia
 *
 */

public class FindTheSmallestMissing {
	
	public static int findTheSmallestMissing(int[] arr,int n) {
		
		int i;
		
		for(i=0;i<arr.length;i++) {
			
			if(arr[i]!=i) { 
				
				return i;
			}
		}
		return i;
	}
	
	public static int findTheSmallestMissing(int[] arr,int start,int end) {
		
		if(start>end) {
			
			return end+1;
		}
		if(start!=arr[start]) {
			
			return start;
		}
		int mid=start+end/2;
		if(arr[mid]==mid) {
			
			return findTheSmallestMissing(arr, mid+1,end);
		}
		return findTheSmallestMissing(arr,start,mid);

	}
	public static void main(String[] args) {
        int arr[] = {0, 1, 2, 6, 9}; 

        int n=arr.length;
		int findTheSmallestMissing = findTheSmallestMissing(arr,n);
		
		System.out.println(findTheSmallestMissing);
		
		int start=0;
		int end=n;
		int findTheSmallestMissing2 = findTheSmallestMissing(arr, start, end-1);
		System.out.println(findTheSmallestMissing2);
		
	}
	
	
}
