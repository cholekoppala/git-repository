/**
 * 
 */
package com.java.incubation.programs;

import java.util.Arrays;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class RearrangeArrayMinMaxTwoPointerTechnique {

	public static void rearrange(int[] arr, int n) {

		// storre the result temp[]
		int[] temp = arr.clone();

		int min = 0;
		int max = n - 1;
		boolean flag = true;

		for (int i = 0; i < n; i++) {

			if (flag) {
//        // to store maximum elements

				arr[i] = temp[max--];
			} else {
//		        // to store min elements

				arr[i] = temp[min++];
			}
			flag = !flag;
		}
	}

	public static void main(String[] args) {

		int arr[] = new int[] { 1, 2, 3, 4, 5, 6 };

		System.out.println("Original Array ");
		System.out.println(Arrays.toString(arr));

		rearrange(arr, arr.length);

		System.out.println("Modified Array ");
		System.out.println(Arrays.toString(arr));

	}

}
