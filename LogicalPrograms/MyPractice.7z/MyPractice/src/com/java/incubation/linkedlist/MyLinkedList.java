package com.java.incubation.linkedlist;

public class MyLinkedList {

	static Node head;

	public void insertData(int data) {

		Node node = new Node();

		node.data = data;
		node.next = null;

		if (head == null) {

			head = node;
		}

		else {

			Node n = head;

			while (n.next != null) {

				n = n.next;
			}
			n.next = node;
		}
	}

	public void show() {

		Node res = head;

		while (res.next != null) {

			System.out.println(res.data);

			res = res.next;
		}
		System.out.println(res.data);
	}

	public void printList(Node node) {

		while (node.next != null) {

			System.out.println(node.data);
			node = node.next;
		}
		System.out.println(node.data);

	}

	public Node reverse(Node node) {

		Node prev = null;
		Node current = node;
		Node next = null;

		while (current != null) {

			next = current.next;
			current.next = prev;
			prev = current;
			current = next;
		}
		node = prev;
		return node;
	}

	public Node reverseMyOwn() {
		Node node = head;
		Node prev = null;
		Node current = node;
		Node next = null;

		while (current != null) {

			next = current.next;
			current.next = prev;
			prev = current;
			current = next;
		}
		node = prev;
		return node;
	}
	
		
		public void deleteAt(int index) {

			if (index == 0) {

				head = head.next;
			} else {

				Node n = head;
				Node n1 = null;
				for (int i = 0; i < index - 1; i++) {

					n=n.next;
				}
				n1=n.next;
				n.next=n1.next;
			}
		}
	

	public static void main(String[] args) {

		MyLinkedList myLinkedList = new MyLinkedList();
		myLinkedList.insertData(10);
		myLinkedList.insertData(20);
		myLinkedList.insertData(30);
		myLinkedList.insertData(40);
		// myLinkedList.show();

		// greek workd logic

		MyLinkedList linkedlist = new MyLinkedList();

//		linkedlist.head=new Node(1);
//		linkedlist.head.next=new Node(2);
//		linkedlist.head.next.next=new Node(3);

		// linkedlist.printList(head);

		// System.out.println();

		head = linkedlist.reverseMyOwn();

		myLinkedList.show();

	}

}
