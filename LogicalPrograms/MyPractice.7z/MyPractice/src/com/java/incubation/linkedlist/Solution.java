package com.java.incubation.linkedlist;
class Solution {
 public static  int getIdenticalTwinsCount (int[] arr) {
       int countIdenticalTwins = 0;
       for (int i = 0; i < arr.length; i++) {
           for (int j = i + 1; j < arr.length; j++) {
               if (arr[i] == arr[j]) {
                   countIdenticalTwins++;
               }
           }
       }
       return countIdenticalTwins;
   }
   
   public static void main(String[] args) {
	
	   int[] arr= {1, 2, 2, 3, 2, 1};
	   
	   int identicalTwinsCount = getIdenticalTwinsCount(arr);
	   
	   System.out.println(arr[identicalTwinsCount]);
	   
	   
}
}