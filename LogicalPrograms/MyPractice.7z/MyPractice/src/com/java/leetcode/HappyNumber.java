/**
 * 
 */
package com.java.leetcode;

import java.util.HashSet;
import java.util.Set;

/**
 * @author Koppala_Choleswaraia
 *
 */
//https://www.youtube.com/watch?v=LkD0D0Xy-ro
public class HappyNumber {

	public static boolean isHappy(int n) {
        // Create a hash set...
        Set<Integer> hset = new HashSet<Integer>();
        // If the number is not in the HashSet, we should add it...
        while (hset.add(n)) {
            // Initialize the total...
            int total = 0;
            // Create a while loop...
            while (n > 0) {
                // Process to get happy number...
                // We use division and modulus operators to repeatedly take digits off the number until none remain...
                // Then squaring each removed digit and adding them together...
                total += (n % 10) * (n % 10);
                n /= 10;
                // Each new converted number must not had occurred before...
            }
            // If total is equal to 1 return true.
            if (total == 1)
                return true;
            // Insert the current number into the set s...
            // Replace the current number with total of the square of its digits.
            else
                n = total;
        }
        // If current number is already in the HashSet, that means we're in a cycle and we should return false..
        return false;
    
	}

	public static boolean happyNumber(int n) {

		HashSet<Integer> hs = new HashSet<>();
		// find the sum of squares
		while (true) {
			int sum = 0;

			while (n != 0) {

				sum = sum + (int) Math.pow(n % 10, 2.0);

				n = n / 10;

			}

			if (sum == 1) {
				return true;
			}
			else {
			n = sum;
			}

			if (hs.contains(n)) {
				return false;
			}
			hs.add(n);

		}

	}

	public static void main(String[] args) {

		boolean happyNumber = happyNumber(19);
		System.out.println(happyNumber);
		boolean happyNumber2 = isHappy(19);
		System.out.println(happyNumber2);

	}

}
