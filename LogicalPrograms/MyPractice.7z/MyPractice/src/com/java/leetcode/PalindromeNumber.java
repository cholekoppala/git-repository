/**
 * 
 */
package com.java.leetcode;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class PalindromeNumber {

	public static boolean palindromeNumber(int x) {
		int remainder;
		int sum = 0;
		int targetNo = x;
		while (0 < x) {

			remainder = x % 10;
			x = x / 10;
			sum = sum * 10 + remainder;

		}
		if (targetNo == sum) {
			return true;
		}
		return false;
	}

	public static void main(String[] args) {

		boolean palindromeNumber = palindromeNumber(121);
		System.out.println(palindromeNumber);
	}

}
