/**
 * 
 */
package com.java.leetcode;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class LengthOfLastWord {
	
	public static void main(String[] args) {
		
		String str="   fly me   to   the moon  ";
		
		
		String[] split = str.trim().split("\\s+");
		
		int len = split[split.length-1].length();
		System.out.println(split[len]);
		
		System.out.println(len);
		
		String[] words = str.split(" ");
		String lastWord="";
		for(String word : words) {
			
			lastWord=word;
		}
		
		System.out.println(lastWord);
	}

}
