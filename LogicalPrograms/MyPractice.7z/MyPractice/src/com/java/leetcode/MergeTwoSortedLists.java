/**
 * 
 */
package com.java.leetcode;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class MergeTwoSortedLists {

	public static ListNode mergeTwoLists(ListNode list1, ListNode list2) {

		ListNode dummy = new ListNode(0);
		ListNode ans = dummy;
		while (list1 != null && list2 != null) {
			if (list1.val <= list2.val) {
				ListNode temp = new ListNode(list1.val);
				dummy.next = temp;
				dummy = dummy.next;
				list1 = list1.next;
			} else {
				ListNode temp = new ListNode(list2.val);
				dummy.next = temp;
				dummy = dummy.next;
				list2 = list2.next;
			}
		}
		while (list1 != null) {
			ListNode temp = new ListNode(list1.val);
			dummy.next = temp;
			dummy = dummy.next;
			list1 = list1.next;
		}
		while (list2 != null) {
			ListNode temp = new ListNode(list2.val);
			dummy.next = temp;
			dummy = dummy.next;
			list2 = list2.next;
		}
		return ans.next;
	}

	public static void main(String[] args) {

		ListNode listNode = new ListNode();

		listNode.next = new ListNode(1);
		listNode.next.next = new ListNode(2);
		listNode.next.next = new ListNode(4);

		ListNode listNode1 = new ListNode();

		listNode1.next = new ListNode(1);
		listNode1.next.next = new ListNode(3);
		listNode1.next.next = new ListNode(4);

		ListNode mergeTwoLists = mergeTwoLists(listNode, listNode1);

		printList(mergeTwoLists);

	}

	public static void printList(ListNode node) {

		while (node.next != null) {

			System.out.println(node.val);
			node = node.next;
		}
		System.out.println(node.val);

	}

}

class ListNode {

	int val;
	ListNode next;

	ListNode() {

	}

	ListNode(int val) {
		this.val = val;
	}

	ListNode(int val, ListNode next) {

		this.val = val;
		this.next = next;
	}

}
