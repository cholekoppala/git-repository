/**
 * 
 */
package com.java.leetcode;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class RemoveElement {

	public static int removeElemetn(int[] arr, int val) {

		int k = 0;
		for (int i = 0; i < arr.length; i++) {

			if (arr[i] != val) {

				arr[k] = arr[i];
				k++;
				System.out.println(arr[k]);
			}

		}
		return k;
	}

	public static void main(String[] args) {

		int[] arr = { 3, 2, 2, 3 };
		int val = 3;

		int removeElemetn = removeElemetn(arr, val);

		
		
	}
}
