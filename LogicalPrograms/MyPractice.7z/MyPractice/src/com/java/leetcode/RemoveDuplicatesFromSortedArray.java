/**
 * 
 */
package com.java.leetcode;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class RemoveDuplicatesFromSortedArray {
	public static int removeDuplicates(int[] arr) {

		int count = 0;

		for (int i = 0; i < arr.length; i++) {

			if (arr[count] != arr[i]) {

				count++;

				arr[count] = arr[i];
			System.out.println(count);	
			}
		}

		return count + 1;
	}

	public static void main(String[] args) {
		int[] arr = { 1, 1, 2 };
		int removeDuplicates = removeDuplicates(arr);
		
		System.out.println(removeDuplicates);
	}

}
