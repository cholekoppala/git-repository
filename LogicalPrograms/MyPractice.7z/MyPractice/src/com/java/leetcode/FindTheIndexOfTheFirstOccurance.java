/**
 * 
 */
package com.java.leetcode;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class FindTheIndexOfTheFirstOccurance {
	
	 public static int strStr(String haystack, String needle) {

	        if(haystack.contains(needle)){
	            return haystack.indexOf(needle);
	        }
	    return -1;
	        
	    }
	
	public static void main(String[] args) {
		
		int strStr = strStr("choleswaraiah","koppala");
		
		System.out.println(strStr);
	}

}
