/**
 * 
 */
package com.java.leetcode;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class MajarityElement {

	public static void main(String[] args) {

	//	int[] arr = {3,2,3};
		
		int[] arr= {2,2,1,1,1,1,1,2,2};
//		
//		Arrays.sort(arr);
//		int n=arr.length;
//		
//		int len = arr[n/2];
//		
//		System.out.println(len);

		LinkedHashMap<Integer, Integer> hm = new LinkedHashMap<>();

		for (int i = 0; i < arr.length; i++) {

			if (hm.get(arr[i]) != null) {

				hm.put(arr[i], hm.get(arr[i]) + 1);

			}

			else {

				hm.put(arr[i],1);
			}
		}
       LinkedHashMap<Integer, Integer> collect = hm.entrySet().stream().sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
       .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,(s1,s2)->s1,LinkedHashMap::new));
       System.out.println(collect);
       Entry<Integer, Integer> entry = collect.entrySet().stream()
       .findFirst().get();
       
       System.out.println(entry.getKey());
       
       
       
    
    }
       
	

}
