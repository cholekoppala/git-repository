/**
 * 
 */
package com.java.leetcode;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class ReverseWord {

	public static void main(String[] args) {

		String str = "  i love my java    programming";
        String[] words = str.split("\\s+");

		//String[] words = str.split(" ");
		String rev = "";
		
		StringBuilder sb = new StringBuilder();

		for (int i = words.length - 1; i >= 0; i--) {

			rev = rev + words[i] + " ";
			
			sb.append(words[i]+" ");

		}

		System.out.println(rev);
		
		System.out.println(sb.toString().trim());

	}

}
