package com.java.threads;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CreateFiveThreadSequentially implements Runnable {

	int index;

	CreateFiveThreadSequentially(int index) {

		this.index = index;
	}

	@Override
	public void run() {
		
		//for(int i=0;i<=100;i++) {
			
			//System.out.println("sequential thread="+i+"="+index);
		System.out.println("sequential thread=="+index);

		//}

	}
	public static void main(String[] args) throws InterruptedException {
		
		CreateFiveThreadSequentially t1 = new CreateFiveThreadSequentially(1);
		CreateFiveThreadSequentially t2 = new CreateFiveThreadSequentially(2);
		CreateFiveThreadSequentially t3 = new CreateFiveThreadSequentially(3);
		CreateFiveThreadSequentially t4 = new CreateFiveThreadSequentially(4);
		CreateFiveThreadSequentially t5 = new CreateFiveThreadSequentially(5);

		Thread thread1 = new Thread(t1);
		Thread thread2 = new Thread(t2);
		Thread thread3 = new Thread(t3);
		Thread thread4 = new Thread(t4);
		Thread thread5= new Thread(t5);
		
//		thread1.start();
//		thread1.join();
//		thread2.start();
//		thread2.join();
//		thread3.start();
//		thread4.join();
//		thread5.start();
//		thread5.join();
//		
		//
		
		ExecutorService nfix = Executors.newFixedThreadPool(10);
		
		nfix.execute(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
				System.out.println("hi thread");
				
			}
		});


		nfix.execute(thread5);
		
		ExecutorService service = Executors.newSingleThreadExecutor();
		
		for(int i=1;i<=5;i++) {
			
			CreateFiveThreadSequentially th = new CreateFiveThreadSequentially(i);
			service.submit(th);
		}

	}

}
