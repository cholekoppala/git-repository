/**
 * 
 */
package com.java.singletone;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class Test {

	/**
	 * @param args
	 * @throws SecurityException 
	 * @throws NoSuchMethodException 
	 * @throws InvocationTargetException 
	 * @throws IllegalArgumentException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 * @throws ClassNotFoundException 
	 */
	@SuppressWarnings("resource")
	public static void main(String[] args) throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, FileNotFoundException, IOException, ClassNotFoundException {
		// TODO Auto-generated method stub

		SeriliazableSingleTone obj1 = SeriliazableSingleTone.getInstance();
		
		ObjectOutputStream op = new ObjectOutputStream(new FileOutputStream("myser.ser"));
		
		op.writeObject(obj1);
		op.close();
		
		ObjectInputStream oi = new ObjectInputStream(new FileInputStream("myser.ser"));
		
		SeriliazableSingleTone obj2 = (SeriliazableSingleTone)oi.readObject();
		oi.close();
		
		
		
       
        System.out.println(obj1.hashCode());
        System.out.println(obj2.hashCode());
        
	}

}
