package com.java.singletone;

public enum EnumSingleton {

    INSTANCE;

    public static void doSomething() {
        // do something
    	System.out.println("do enum something");
    }
}