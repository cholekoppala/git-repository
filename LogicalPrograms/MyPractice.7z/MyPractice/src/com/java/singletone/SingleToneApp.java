package com.java.singletone;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;

public class SingleToneApp {
	//https://www.digitalocean.com/community/tutorials/java-singleton-design-pattern-best-practices-examples
	public static void main(String[] args) throws Exception {
		
		SeriliazableSingleTone obj = SeriliazableSingleTone.getInstance();
		//breaking singletone
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("singleton.ser"));
		out.writeObject(obj);
		out.close();
 
		ObjectInputStream in = new ObjectInputStream(new FileInputStream("singleton.ser"));
		SeriliazableSingleTone obj2 = (SeriliazableSingleTone) in.readObject();
		in.close();

        System.out.println(obj.hashCode());
        System.out.println(obj2.hashCode());
        
        //reflection api singletone breaking
        
             // breaking singleton pattern
     		// Using reflection to break the Singleton pattern
            ReflecationSingleTone obj1 = ReflecationSingleTone.getInstance();
     		Constructor<ReflecationSingleTone> constructor = ReflecationSingleTone.class.getDeclaredConstructor();
     		constructor.setAccessible(true);
     		ReflecationSingleTone newInstance1 = constructor.newInstance();
     		System.out.println(obj1 == newInstance1); //false
     		System.out.println(obj1.hashCode());
     		System.out.println(newInstance1.hashCode());
     		
     		//enum handle singletone not breaking
     		
     EnumSingleton.INSTANCE.doSomething();
	}

}
