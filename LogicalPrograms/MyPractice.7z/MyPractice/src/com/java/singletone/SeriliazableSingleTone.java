/**
 * 
 */
package com.java.singletone;

import java.io.Serializable;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class SeriliazableSingleTone implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private SeriliazableSingleTone() {
		
		
	}
	
	private static SeriliazableSingleTone instance;
	
	public static SeriliazableSingleTone getInstance() {
		
		if(instance==null) {
			
			return instance=new SeriliazableSingleTone();
		}
		return instance;
	}
	protected Object readResolve() {
	    return instance;
	}
}
