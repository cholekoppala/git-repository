package com.java.singletone;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;

public class SingletonClassTest {
 
	public static void main(String[] args) throws Exception {
		SingletonClassExample obj1 = SingletonClassExample.getInstance();
		
		//  obj1.display(); System.out.println(obj1.hashCode());
		 
 
		SingletonClassExample obj2 = SingletonClassExample.getInstance();
		
		 // obj2.display(); System.out.println(obj2.hashCode());
		 
 
		System.out.println(obj1 == obj2);// true
 
		// breaking singleton pattern
		// Using reflection to break the Singleton pattern
		Constructor<SingletonClassExample> constructor = SingletonClassExample.class.getDeclaredConstructor();
		constructor.setAccessible(true);
		SingletonClassExample newInstance1 = constructor.newInstance();
		System.out.println(obj1 == newInstance1); //false
 
		// Serializing and then deserializing to break the Singleton pattern
		SingletonClassExample singleton = SingletonClassExample.getInstance();
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("singleton.ser"));
		out.writeObject(singleton);
		out.close();
 
		ObjectInputStream in = new ObjectInputStream(new FileInputStream("singleton.ser"));
		SingletonClassExample newInstance2 = (SingletonClassExample) in.readObject();
		in.close();
 
		System.out.println(singleton == newInstance2); // false
	}
}