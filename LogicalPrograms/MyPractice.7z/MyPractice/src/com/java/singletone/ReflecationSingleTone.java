/**
 * 
 */
package com.java.singletone;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class ReflecationSingleTone {

	private static ReflecationSingleTone instance;

	private ReflecationSingleTone() throws Exception {
		
		 if (instance != null) { 
		 throw new Exception("Trying to break Singleton pattern");
		 }

	}


	public static ReflecationSingleTone getInstance() throws Exception {

		if (instance == null) {

			return instance = new ReflecationSingleTone();
		}
		return instance;
	}

	protected Object readResolve() {
		return instance;
	}

}
