package com.java.singletone;

import java.io.Serializable;

public class SingletonClassExample implements Serializable {
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static SingletonClassExample INSTANCE;
 
	private SingletonClassExample() throws Exception {
		
//		  if (INSTANCE != null) throw new
//		  Exception("Trying to break Singleton pattern");
//		 
 
	}
 
	public static SingletonClassExample getInstance() throws Exception {
		if (INSTANCE == null)
			INSTANCE = new SingletonClassExample();
 
		return INSTANCE;
	}
 
	
	  protected Object readResolve() { // Return the true singleton instance return
  return INSTANCE; 
	  }
	 
 
//	public void display() {
//		System.out.println("Hello");
//	}
}