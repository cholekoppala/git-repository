package com.java.jaxb;

public class Marshalling {

}
