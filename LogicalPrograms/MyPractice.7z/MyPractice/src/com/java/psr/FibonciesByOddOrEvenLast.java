/**
 * 
 */
package com.java.psr;

import java.util.Collections;
import java.util.LinkedHashSet;

/**
 * 
 */
public class FibonciesByOddOrEvenLast {
	
	public static void main(String[] args) {
		
		int t1 = 0;
		int t2 = 1;
		LinkedHashSet<Integer> lhs = new LinkedHashSet<>();
		for (int i = 0; i <= 10; i++) {

			System.out.print(t1 + " ");
			lhs.add(t1);
			int sum = t1 + t2;
			t1 = t2;
			t2 = sum;
		}
		System.out.println(lhs);
		Collections.reverseOrder();
		Integer number = lhs.stream().sorted(Collections.reverseOrder()).findFirst().get();
		
		if(number%2==0) {
			
			System.out.println("even no="+number);
		}
		else {
			
			System.out.println("odd no="+number);
		}
	
	}

}
