/**
 * 
 */
package com.java.psr;

import java.util.Arrays;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class RearrangeHighestPossible {

	public static void main(String[] args) {

		 int arr[] = {1, 34, 3, 98, 9, 76, 45, 4};
		 
		 Arrays.stream(arr)
		 .boxed().sorted((a,b)->b.compareTo(a))
		 .forEach(i->System.out.print(i + " "));


	}

}
