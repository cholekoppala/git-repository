package com.java.psr;
public class CountOccuranceOfChar1  
{  

public static void main(String args[])  
{  
	String str = "choleswaraiah";
	char[] ch = str.toCharArray();
	int[] freq = new int[str.length()];
    int i,j;
	for ( i = 0; i < ch.length; i++) {
		freq[i] = 1;
		for ( j = i + 1; j < ch.length; j++) {

			if (ch[i] == ch[j]) {

				freq[i]++;
				ch[j] = '0';
			}
		}
	}
	
	for(i=0;i<freq.length;i++) {
		
		if(ch[i]!=' ' && ch[i]!='0' ) {
			
			
			System.out.println(ch[i]+" "+freq[i]);
			
		}
		
	}

}  
}  