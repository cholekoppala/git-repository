package com.java.psr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListContainsAlphaNumericValuesFindoutIntegersList {

	//using java legacy logic
	public static List<Integer> ListContainsAlphaNumericValuesFindoutIntegersList(List<String> list) {

		List<Integer> integerList = new ArrayList<>();
		for (String string : list) {
			try {

				int parseInt = Integer.parseInt(string);

				integerList.add(parseInt);

			} catch (NumberFormatException e) {
			}

		}
		return integerList;
	}
	// using java 8
	
	public static void ListContainsAlphaNumericValuesFindoutIntegersListUsingJava8(List<String> list) {
		
    list.stream().filter(ls->ls.matches("[0-9]+")).forEach(res->{
			
			System.out.println(res);
		});
	}


	public static void main(String[] args) {
		List<String> list = Arrays.asList("as", "123", "32", "2as");
        //legacy
		System.out.println(ListContainsAlphaNumericValuesFindoutIntegersList(list));
		//java8		
		//ListContainsAlphaNumericValuesFindoutIntegersListUsingJava8(list);
	}

}
