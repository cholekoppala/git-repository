package com.java.psr.quiz;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class App {
	
	public static void hashMap2() {
		
		Map<Integer, Integer> map = new HashMap<>(10);

		for (int i = 1; i <= 10; i++) {

		map.put(i, i * i);

		}

		System.out.println(map.get(4));


	}
	public static void map() {
		
		Map m = new HashMap();

		m.put(123, "456");

		m.put("abc", "def");

	//	System.out.println(m.contains("123"));
		
	}
	public static void comparactor() {
		
		Comparator<Integer> c = (o1, o2) -> o2-o1;

		List<Integer> list = Arrays.asList(5, 4, 7, 1);

		Collections.sort(list, c);

		System.out.println(Collections.binarySearch(list, 1));
	}
	
	public static void hashMap() {
		
		Map<String, Double> map = new HashMap<>();
		     map.put("pi", 3.14159);

		//	map.put("e", 2L);

		 map.put("log(1)", new Double(0.0));

			//map.put('x', new Double(123.4));

	}
	
	public static void set() {
		
		Set<String> s = new HashSet<>();

		s.add("lion");

		s.add("tiger");

		s.add("bear");

		s.forEach(System.out::println);


	}
	
	public static void mapMerge() {
		
		
		Map<Integer, Integer> map = new HashMap<>();

		map.put(1, 10);

		map.put(2, 20);

		map.put(3, null);

		map.merge(1, 3, (a,b) -> a + b);

		map.merge(3, 3, (a,b) -> a + b);

		System.out.println(map);


	}
	
	public static void treeset() {
		
		TreeSet<String> tree = new TreeSet<String>();

		tree.add("one");

		tree.add("One");

		tree.add("ONE");

		System.out.println(tree.ceiling("On"));


	}
	
	public void dispaly() {
		Set<Number> numbers = new HashSet<>();

		numbers.add(new Integer(86));

		numbers.add(75);

		numbers.add(new Integer(86));

		 numbers.add(null);

		numbers.add(309L);

		Iterator iter = numbers.iterator();

		while (iter.hasNext())

	   System.out.print(iter.next());


		
	}
	
	public static void main(String[] args) {
		
  // treeset();
	//	hashMap2();
		//comparactor();
		mapMerge();
		
	}

}
