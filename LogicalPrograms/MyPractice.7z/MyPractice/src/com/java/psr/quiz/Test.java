package com.java.psr.quiz;
public class Test {

	 public void print(Integer i) {
	        System.out.println("Integer");
	    }

	  
	    public void print(long i) {
	        System.out.println("long");
	    }
	    public void print(int i) {
	        System.out.println("int");
	    }
	    public static void main(String args[]) {
	        Test test = new Test();
	        test.print(10);
	    }
	    
	    public interface Animal { public default String getName() { return null; } }
	     interface Mammal { public default String getName() { return null; } }
	     abstract class Otter implements Mammal, Animal {}
	    
	}