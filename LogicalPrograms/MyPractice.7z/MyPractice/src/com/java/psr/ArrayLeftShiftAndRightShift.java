package com.java.psr;

import java.util.Arrays;

public class ArrayLeftShiftAndRightShift {
	
	
	public static void main(String[] args) {
		
		int[] arr= {1,5,6,2,3,4,9};
		
		int size=arr.length/2;
		
		int j=0;
		int[] temp=new int[arr.length];
		for(int i=size;i<arr.length;i++) {
			
			temp[j]=arr[i];
			j++;
		}
		for(int i=0;i<size;i++) {
			
			temp[j]=arr[i];
			j++;
		}
		System.out.println(Arrays.toString(temp));
	}

}
