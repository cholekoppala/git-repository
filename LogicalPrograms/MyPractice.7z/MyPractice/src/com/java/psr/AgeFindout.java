/**
 * 
 */
package com.java.psr;

import java.time.LocalDate;
import java.time.Period;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class AgeFindout {
	
	public static void main(String[] args) {
		
		LocalDate dob = LocalDate.parse("1993-01-02");
		
		LocalDate currentDate = LocalDate.now();
		
		Period between = Period.between(dob, currentDate);
		
		int years = between.getYears();
		
		System.out.println(years);
	}

}
