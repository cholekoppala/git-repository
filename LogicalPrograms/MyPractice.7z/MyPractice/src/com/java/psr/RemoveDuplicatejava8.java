/**
 * 
 */
package com.java.psr;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class RemoveDuplicatejava8 {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(5, 3, 4, 1, 3, 7, 2, 9, 9, 4);
		LinkedHashSet<Integer> hs = new LinkedHashSet<>();

		Set<Integer> collect2 = list.stream().filter(ls -> hs.add(ls) == false).collect(Collectors.toSet());

		System.out.println(collect2);

		LinkedHashSet<Integer> collect = list.stream().filter(ls -> hs.add(ls) == false)
				.collect(Collectors.toCollection(LinkedHashSet::new));

		System.out.println(collect);
		
		Set<Integer> collect3 = list.stream()
		.filter(ls->Collections.frequency(list, ls)>1)
		.collect(Collectors.toSet());
		
		System.out.println(collect3);
		
		Set<Integer> collect4 = list.stream()
        .collect(Collectors.groupingBy(Function.identity()
                , Collectors.counting()))    // create a map {1=1, 2=1, 3=2, 4=2, 5=1, 7=1, 9=2}
        .entrySet().stream()                 // Map -> Stream
        .filter(m -> m.getValue() > 1)       // if map value > 1, duplicate element
        .map(Map.Entry::getKey)
        .collect(Collectors.toSet());
		
		System.out.println(collect4);
	}

}
