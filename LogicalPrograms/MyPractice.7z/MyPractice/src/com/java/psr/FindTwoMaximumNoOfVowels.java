package com.java.psr;

import java.util.stream.Stream;

public class FindTwoMaximumNoOfVowels {

	// java legacy
	public static void FindMaximumNoOfVowels(String input) {

		String wordMostVowels = "";

		for (String word : input.split(" ")) {
			int vowelCount = 0;
			for (char c : word.toLowerCase().toCharArray()) {
				if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
					vowelCount++;
				}
			}

			if (1 < vowelCount) {
				wordMostVowels = word;
				System.out.println(wordMostVowels);
			}
		}

	}
	
	// java8 
	public static void FindMaximumNoOfVowelsUsingJava8(String input) {
		
		Stream.of(input.split(" ")).filter(vowel->vowel.replaceAll("[^aeiou]", "").length()==2)
		.forEach(res->{
			System.out.println(res);
		});
	}


	public static void main(String args[]) {
		String sentence = "The quick brown fox jumps right over the little lazy dog";
        //java legacy
		FindMaximumNoOfVowels(sentence);
		System.out.println();
		//java8
		FindMaximumNoOfVowelsUsingJava8(sentence);

	}
}