/**
 * 
 */
package com.java.psr;

/**
 * 
 */
public class FrequecyCharacterCount {

	public static void main(String[] args) {

		String str = "aabcdefghelke";
		int[] freq = new int[str.length()];

		char[] ch = str.toCharArray();
		for (int i = 0; i < ch.length; i++) {
			freq[i] = i;
			for (int j = i + 1; j < ch.length; j++) {

				if (ch[i] == ch[j]) {

					freq[i]++;
					ch[j] = '0';
				}
			}
		}
		
		for(int j=0;j<freq.length;j++) {
			
			if(ch[j]!=' ' && ch[j]=='0') {
				
				System.out.println(ch[j]+"="+freq[j]);
			}
		}

	}

}
