/**
 * 
 */
package com.java.psr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class OptionalJavaElseThrow {

	public static void main(String[] args) {

		ArrayList<String> list = new ArrayList<>();
		list.add(null);

		System.out.println(list);

		ArrayList<String> orElseThrow = Optional.ofNullable(list).filter(s -> list.size() > 1)
				.orElseThrow(() -> new RuntimeException("it is null value dont do the size"));

		Optional.ofNullable(list).filter(r -> r.size() > 1).orElse(null);

		System.out.println(orElseThrow);

		List<Integer> list1 = Arrays.asList(10, 20, 30, 40, 50, 10);

		Integer orElseThrow1 = list1.stream().findFirst()
				.orElseThrow(() -> new RuntimeException("value is not presented"));

		System.out.println(orElseThrow1);
	}

}
