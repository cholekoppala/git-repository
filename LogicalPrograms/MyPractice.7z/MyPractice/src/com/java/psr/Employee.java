package com.java.psr;

public class Employee {

	private String empName;
	private Integer empId;
	private Integer empSal;
	private Double empAvgSal;

	private String empDept;

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public Integer getEmpSal() {
		return empSal;
	}

	public void setEmpSal(Integer empSal) {
		this.empSal = empSal;
	}

	public Double getEmpAvgSal() {
		return empAvgSal;
	}

	public void setEmpAvgSal(Double empAvgSal) {
		this.empAvgSal = empAvgSal;
	}

	public Employee(String empName, Integer empId, Integer empSal, Double empAvgSal, String empDept) {
		super();
		this.empName = empName;
		this.empId = empId;
		this.empSal = empSal;
		this.empAvgSal = empAvgSal;
		this.empDept = empDept;
	}

	@Override
	public String toString() {
		return "Employee [empName=" + empName + ", empId=" + empId + ", empSal=" + empSal + ", empAvgSal=" + empAvgSal
				+ ", empDept=" + empDept + "]";
	}

	public String getEmpDept() {
		return empDept;
	}

	public void setEmpDept(String empDept) {
		this.empDept = empDept;
	}

}
