package com.java.psr;

public class ReverseStringWithoutAffectingSpecialCharacters {
	
	
	public static char[] withoutSpecialCharacterReverse(char[] ch) {
		
		
		int left=0;
		int right=ch.length-1;
	 // Traverse string from both ends until 'left' and 'right'

		while(left<right) {
			//Ignore special characters
			if(!Character.isAlphabetic(ch[left])) {
				
				left++;
			}
			
			else if(!Character.isAlphabetic(ch[right])) {
				
				right--;
			}
            // Both ch[left] and ch[right] are not spacial

			else {
				
				char temp=ch[left];
				
				ch[left]=ch[right];
				ch[right]=temp;
				left++;
				right--;
				
			}
		}
		return ch;

	}

	public static void main(String[] args) {
		
	 String str="a!!!b.c.d,e',ghi";
		
		char[] ch = str.toCharArray();
	System.out.println(withoutSpecialCharacterReverse(ch));
	}

}
