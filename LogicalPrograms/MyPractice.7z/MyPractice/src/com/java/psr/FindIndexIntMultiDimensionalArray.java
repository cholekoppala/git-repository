package com.java.psr;

import java.util.Arrays;

public class FindIndexIntMultiDimensionalArray {
	
    
    public static int[] getFindMultiDimension(int[][] arr,int key){
    	
        int[] result= {-1,-1};
        
        for(int i=0;i<arr.length;i++) {
        	
        	for(int j=0;j<arr[i].length;j++) {
        		
        		if(arr[i][j]==key) {
        			
        			result[0]=i;
        			result[1]=j;
        		
        		}
        	}
        }
        return result;

    }

	public static void main(String[] args) {
		
		
        int[][] intArray = { { 1, 2 }, { 3, 4 },{5,6}}; 
        int key=6;
        
        int[] findMultiDimension = getFindMultiDimension(intArray, key);
        
        System.out.println(Arrays.toString(findMultiDimension));
        

	}

}
