package com.java.psr;

import java.util.LinkedHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

public class StringDuplicatesCount {
	
	public static void main(String[] args) {

		String str = "aaaabbbccd";// Output - a4b3c2d1

		LinkedHashMap<Character, Long> lh = str.chars().mapToObj(c -> (char) c)
				.collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()));
		
		
		String res=lh.entrySet().stream().map(mp->new StringBuilder().append(mp.getKey()+""+String.valueOf(mp.getValue())))
		.collect(Collectors.joining(""));
		
		System.out.println(res);
		
		
	}

}
