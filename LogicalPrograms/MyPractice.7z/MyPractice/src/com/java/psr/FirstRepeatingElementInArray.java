package com.java.psr;

import java.util.Arrays;
import java.util.LinkedHashSet;

public class FirstRepeatingElementInArray {

	public static int FirstRepeatingElementInArray(int arr[], int n) {

		for (int i = 0; i < n; i++) {

			for (int j = i + 1; j < n; j++) {

				if (arr[i] == arr[j]) {

					return i;
				}

			}
		}
		return -1;

	}

	public static void main(String[] args) {

		int arr[] = { 6, 10, 5, 4, 6, 9, 120, 4, 10 };

		int result = FirstRepeatingElementInArray(arr, arr.length);

		if (result == -1) {

			System.out.println("There is no non-repeating element=" + arr[result]);
		} else {

			System.out.println("Non repeating element is=" + arr[result]);
		}

		// java8
		LinkedHashSet<Integer> ls = new LinkedHashSet<>();

		int res = Arrays.stream(arr).filter(data -> ls.add(data) == false).findFirst().getAsInt();

		System.out.println(res);

	}

}
