package com.java.psr;

import java.util.LinkedHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CountNoOfCharacterInString {
	
	//java8
	public static void noOfOccurenceForEachCharacterJava8(String str) {
		
		str.chars().mapToObj(c->(char)c)
		.collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
		.entrySet().stream().forEach((k)->{
			
			System.out.println(k.getKey()+"="+k.getValue());
		});

	}
	
  //legacy
  public static void noOfOccurenceForEachCharacter(String str) {
		
		char[] ch = str.toCharArray();
		
		LinkedHashMap<Character,Integer> ls=new LinkedHashMap<>();
		
		for(int i=0;i<ch.length;i++) {
			
		//	ls.put(ch[i], ls.getOrDefault(ch[i], 0)+1);
			if(ls.get(ch[i])!=null) {
				
				ls.put(ch[i], ls.get(ch[i])+1);
			}
			else {
				
				ls.put(ch[i], 1);
			}
		}
     System.out.println(ls);
	}
	
	
	public static void main(String[] args) {
		
		String str="choleswaraiah";
		//java8
		noOfOccurenceForEachCharacterJava8(str);
		//legacy
		noOfOccurenceForEachCharacter(str);
		
	}

}
