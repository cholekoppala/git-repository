package com.java.psr;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class GroupByDeptMaxSal {
	
	public static void main(String[] args) {
		
		Employee e1 = new Employee("chole", 12, 9999, 999.00, "hr");
		Employee e2 = new Employee("siva", 123, 89999, 877.00, "it");
		Employee e3 = new Employee("ravi", 125, 12344, 543.00, "finance");
		Employee e4 = new Employee("kiran", 129, 65444, 8177.00, "it");
		Employee e5 = new Employee("suresh", 129, 12844, 5433.00, "finance");
		Employee e6 = new Employee("chole", 12, 9999, 999.00, "hr");

		
		List<Employee> list = List.of(e1,e2,e3,e4,e5,e6);
		
		Map<String, Optional<Employee>> collect = list.stream()
	    .collect(Collectors.groupingBy(Employee::getEmpDept,
	     Collectors.maxBy(Comparator.comparing(Employee::getEmpSal))));
		

		
        System.out.println(collect);

	}

}
