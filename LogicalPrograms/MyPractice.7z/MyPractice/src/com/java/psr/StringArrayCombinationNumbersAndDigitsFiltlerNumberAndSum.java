/**
 * 
 */
package com.java.psr;

import java.util.ArrayList;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class StringArrayCombinationNumbersAndDigitsFiltlerNumberAndSum {

	public static void main(String[] args) {
		//String st1=st.replaceAll("[^A-Za-z]", "");  

		String[] word = { "ch3", "siva7", "hfuu6" };
		ArrayList<Integer> ls = new ArrayList<>();
		int sum=0;
		for (String string : word) {

			String numbers = string.replaceAll("[^0-9]", "");

			int numeric = Integer.parseInt(numbers);
			sum=sum+numeric;
			
		}
		ls.add(sum);

		System.out.println(ls);

	}

}
