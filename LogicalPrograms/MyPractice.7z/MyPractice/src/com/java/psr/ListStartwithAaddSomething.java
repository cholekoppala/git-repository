/**
 * 
 */
package com.java.psr;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 
 */
public class ListStartwithAaddSomething {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String> list = new ArrayList<>();

		list.add("abc");
		list.add("abcd");
		list.add("bcde");

		List<StringBuilder> result = list.stream().filter(ls -> ls.startsWith("a"))
				.map(re -> new StringBuilder(re).append("ing")).collect(Collectors.toList());

		System.out.println(result);

	}

}
