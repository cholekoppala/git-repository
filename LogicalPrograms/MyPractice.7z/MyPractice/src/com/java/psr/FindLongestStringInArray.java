package com.java.psr;

import java.util.Arrays;

public class FindLongestStringInArray {
	
	public static void main(String[] args) {
		
		String[] arr= {"chennai","hyderabad","banglore","mumbai"};
		
		String maxString = Arrays.stream(arr).reduce((word1,word2)->word1.length()>word2.length()?word1:word2).get();
	    System.out.println(maxString);
	}

}
