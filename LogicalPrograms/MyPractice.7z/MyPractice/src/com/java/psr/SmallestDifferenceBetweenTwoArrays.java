package com.java.psr;

public class SmallestDifferenceBetweenTwoArrays {
	public static int findSmallestDifference(int[] A, int[] B, int len1, int len2) {

		int minDiff = Integer.MAX_VALUE;
        int pair1 = 0;
        int pair2 = 0;
		for (int i = 0; i < len1; i++) {

			for (int j = 0; j < len2; j++) {

				int diff = Math.abs(A[i] - B[j]);

				if (diff < minDiff) {

					minDiff = diff;
					
					pair1=A[i];
					pair2=B[j];
				}
			}
		}
		System.out.println("Pair="+pair1+" "+pair2);
		return minDiff;
	}

	public static void main(String[] args) {

		int[] A = { 1, 3, 15, 11, 2 };

		int[] B = { 23, 127, 235, 19, 8 };

		int len1 = A.length;
		int len2 = B.length;

		int findSmallestDifference = findSmallestDifference(A, B, len1, len2);
		System.out.println("output="+findSmallestDifference);
	}

}
