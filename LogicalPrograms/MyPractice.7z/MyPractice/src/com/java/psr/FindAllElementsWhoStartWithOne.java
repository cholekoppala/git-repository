package com.java.psr;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FindAllElementsWhoStartWithOne {
	
	public static void main(String[] args) {
		
		
	List<Integer> list=Arrays.asList(10,20,40,21,15,18,50,89,74);
	
	List<Integer> collect = list.stream().filter(ls->ls.toString().startsWith("1"))
	.collect(Collectors.toList());
	
	List<String> collect2 = list.stream().map(Object::toString).filter(s->s.startsWith("1")).collect(Collectors.toList());
	
	System.out.println(collect);
	System.out.println(collect2);
		
		
	}

}
