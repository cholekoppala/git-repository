package com.java.psr;

import java.util.Arrays;

public class FindFirstNonRepeatedCharacter {
	
	public static void main(String[] args) {
		
		String  str= "The quick brown fox jumps over the lazy dog";
		String res = Arrays.stream(str.split("")).filter(c -> str.indexOf(c) == str.lastIndexOf(c)).findFirst().get();
		System.out.println(res);

	}

}
