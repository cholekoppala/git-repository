package com.java.psr;

import java.util.stream.Stream;

public class StringWordMaximumLengthWordDisplay {

	public static String maxwordLength(String str) {

		String[] words = str.split(" ");
		String max = words[0];
		for (int i = 0; i < words.length; i++) {

			if (max.length() < words[i].length()) {

				max = words[i];
			}

		}

		return max;

	}

	public static void main(String[] args) {

		String str = "I am chole programming language choleswaraiah";

		System.out.println(maxwordLength(str));
		
		// java8
		
		String maxWord = Stream.of(str.split(" ")).reduce((word1,word2)->word1.length()>word2.length()?word1:word2).get();
		
        System.out.println(maxWord);
	}

}
