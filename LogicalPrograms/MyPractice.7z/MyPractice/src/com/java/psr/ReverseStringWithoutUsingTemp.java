/**
 * 
 */
package com.java.psr;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class ReverseStringWithoutUsingTemp {

	public static String withoutUsingTemp(char[] ch, int start, int end) {

		while (start < end) {
			ch[start] ^= ch[end];
			ch[end] ^= ch[start];
			ch[start] ^= ch[end];

			return withoutUsingTemp(ch, start+1, end-1);
		}
		return String.valueOf(ch);
	}

	public static void main(String[] args) {

		String str = "choleswaraiah";
		char[] ch = str.toCharArray();
		int start = 0;
		int end = ch.length - 1;
		String withoutUsingTemp = withoutUsingTemp(ch, start, end);
		System.out.println(withoutUsingTemp);

	}

}
