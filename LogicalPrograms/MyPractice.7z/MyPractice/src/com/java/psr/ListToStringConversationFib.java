/**
 * 
 */
package com.java.psr;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 */
public class ListToStringConversationFib {
public static String getfib() {
		
		int t1=0;
		int t2=1;	
		List<String>list=new ArrayList<>();
		for(int i=0;i<10;i++) {
			list.add(Integer.toString(t1));

			int temp=t1+t2;
			t1=t2;
			t2=temp;
		}
		 return String.join(",", list);
	}

	public static void main(String[] args) {
		
		String getfib = getfib();
		System.out.println(getfib);
	}

}
