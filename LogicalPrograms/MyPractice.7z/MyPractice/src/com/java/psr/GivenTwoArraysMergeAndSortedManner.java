package com.java.psr;

import java.util.Arrays;
import java.util.stream.Stream;

public class GivenTwoArraysMergeAndSortedManner {

	public static void getTWoArraysMerge() {

		int a1[] = { 1, 3, 4, 5 };
		int a2[] = { 2, 5, 8, 9 };

		Stream<Integer> arr1 = Arrays.stream(a1).boxed();
		Stream<Integer> arr2 = Arrays.stream(a2).boxed();

		int[] array = Stream.concat(arr1, arr2).distinct().sorted().mapToInt(Integer::intValue).toArray();

		System.out.println(Arrays.toString(array));

	}
	
	public static void gettwostringsarraysmerge() {
		String[] s1 = { "chole", "siva" };
		String[] s2 = { "ravi", "guru" };

		String[] array = Stream.of(s1, s2).flatMap(Stream::of).toArray(String[]::new);

		Stream<String> arr1 = Arrays.stream(s1);
		Stream<String> arr2 = Arrays.stream(s2);
		String[] array3 = Stream.concat(arr1, arr2).toArray(String[]::new);
		System.out.println(Arrays.toString(array3));
		String[] array2 = Stream.concat(Arrays.stream(s1), Arrays.stream(s2)).toArray(String[]::new);

		System.out.println(Arrays.toString(array));
		System.out.println(Arrays.toString(array2));
	}

	public static void main(String[] args) {
		getTWoArraysMerge();

		int arr1[] = { 1, 3, 4, 5 };
		int arr2[] = { 2, 4, 6, 8 };

		int[] finalArray = new int[arr1.length + arr2.length];

		for (int i = 0; i < arr1.length; i++) {

			finalArray[i] = arr1[i];
		}

		for (int j = 0; j < arr2.length; j++) {

			finalArray[arr1.length + j] = arr2[j];
		}

		for (int k = 0; k < finalArray.length; k++) {

			Arrays.sort(finalArray);
			System.out.print(finalArray[k] + " ");
		}
	}

}
