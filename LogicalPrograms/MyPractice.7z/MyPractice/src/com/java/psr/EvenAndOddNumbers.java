/**
 * 
 */
package com.java.psr;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class EvenAndOddNumbers {
	
	public static void main(String[] args) {
		
		List<Integer> intList = Arrays.asList(10,20,30,40,50,11,23,15,17,2,4,6);

		List<List<Integer>> lists = intList.stream()
		        .collect(Collectors.groupingBy(key->key%2==0,Collectors.toList()))
		        .entrySet().stream().map(e->e.getValue()).collect(Collectors.toList());
		        System.out.println(lists);
		        
		        List<List<Integer>> collect = intList.stream().collect(Collectors.groupingBy(key->key%2==0,Collectors.toList()))
		        .entrySet().stream().map(e->e.getValue()).collect(Collectors.toList());
		        
		        System.out.println(collect);
		        
		        List<List<Integer>> collect2 = intList.stream()
                .collect(Collectors.partitioningBy(integerValue->integerValue%2==0))
                .entrySet().stream().map(mapValue->mapValue.getValue()).collect(Collectors.toList());

	
		        Map<Boolean, List<Integer>> partitions = intList.stream()
		                .collect(Collectors.partitioningBy(x -> x % 2 == 0));
		        List<Integer> evens = partitions.get(true);
		        List<Integer> odds = partitions.get(false);
		        
		        
	
	}

}
