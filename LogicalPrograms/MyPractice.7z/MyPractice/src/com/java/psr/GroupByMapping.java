package com.java.psr;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GroupByMapping {
	
public static void main(String[] args) {
	
	Employee e1 = new Employee("chole", 1, 788, 90.0, "mca");
	Employee e2 = new Employee("soni", 2, 667, 190.0, "mba");
	Employee e3 = new Employee("suresh", 3, 2345, 690.0, "pg");
	
	List<Employee> list=Arrays.asList(e1,e2,e3);
	
    Map<String, List<String>> collect = list.stream()
    .collect(Collectors.groupingBy(Employee::getEmpDept,Collectors.mapping(Employee::getEmpName, Collectors.toList())));
    
    Map<String, List<String>> collect2 = list.stream()
    .collect(Collectors.groupingBy(Employee::getEmpDept,Collectors.mapping(Employee::getEmpName, Collectors.toList())));
    
    System.out.println(collect2);
   
}

}
