/**
 * 
 */
package com.java.psr;

import java.util.Arrays;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class LongestPrefix {
	public static String LongestPrefix(String[] strs) {

		if (strs.length == 0) {

			return "";
		}
		String prefix = strs[0];

		for (int i = 0; i < strs.length; i++) {

			while (strs[i].indexOf(prefix) != 0) {

				prefix = prefix.substring(0, prefix.length() - 1);

				if (prefix.isEmpty()) {

					return "";
				}

			}
		}
		return prefix;

	}

	public static String LongestPrefix1(String[] strs) {

		Arrays.sort(strs);
		String first = strs[0];
		String last = strs[strs.length - 1];

		int idx = 0;

		while (idx < first.length() && idx < last.length()) {

			if (first.charAt(idx) == last.charAt(idx)) {
				idx++;

			}

			else {

				break;
			}
		}
		return first.substring(0, idx);
	}

	public static void main(String[] args) {

		String str[] = { "flower", "flow", "flight" };

		System.out.println(LongestPrefix(str));

	}

}
