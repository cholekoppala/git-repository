package com.java.psr;

public class FindNextGreatestElementInArray {

	static void FindNextGreatestElement(int arr[], int n) {
		int next;
		for (int i = 0; i < n; i++) {
			next = -1;
			for (int j = i + 1; j < n; j++) {
				if (arr[i] < arr[j]) {
					next = arr[j];
					break;
				}
			}
			System.out.println(arr[i] + " -> " + next);
		}
	}

	public static void main(String args[]) {
		int arr[] = { 15, 10, 16, 20, 8, 9, 7, 50 };
		int n = arr.length;
		FindNextGreatestElement(arr, n);
	}

}
