package com.java.psr;

import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.*;
public class FindFirstNonRepeatingElement {
	
	public static void main(String[] args) {
		
		String str="choleswaraiah";
		Character character = str.chars().mapToObj(c->(char)c)
		.collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
		.entrySet().stream().filter(r->r.getValue()==1).map(x->x.getKey()).
		findFirst().get();
		
		System.out.println(character);
		
		
		 Character character1= str.chars().mapToObj(c->(char)c)
			       .collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
			       .entrySet().stream().filter(x->x.getValue()==1).map(r->r.getKey())
			       .skip(1).findFirst().get();
			      
			      
			        System.out.println(character1);
		
	}

}
