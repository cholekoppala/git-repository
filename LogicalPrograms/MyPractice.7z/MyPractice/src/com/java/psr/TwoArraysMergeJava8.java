package com.java.psr;

import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class TwoArraysMergeJava8 {

	public static void main(String[] args) {
		
		int a1[] = { 1, 3, 4, 5 };
		int a2[] = { 2, 5, 8, 9 };	
		
		Stream<Integer> arr1 = Arrays.stream(a1).boxed();
		Stream<Integer> arr2 =Arrays.stream(a2).boxed();
		
			int[] array = Stream.concat(arr1, arr2)
			.distinct()
			.sorted()
			.mapToInt(Integer::intValue)
			.toArray();
			
			System.out.println(Arrays.toString(array));
			
			int[] array2 = IntStream.concat(Arrays.stream(a1), Arrays.stream(a2))
					.distinct().sorted().toArray();
					
					System.out.println(Arrays.toString(array2));

	}

}
