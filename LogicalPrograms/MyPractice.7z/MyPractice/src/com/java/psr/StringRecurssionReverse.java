package com.java.psr;

public class StringRecurssionReverse {

	static char[] reverse(char[] arr, int start, int end) {

		if (start > end) {

			return arr;
		}
		char temp = arr[start];
		arr[start] = arr[end];
		arr[end] = temp;
		reverse(arr, start + 1, end - 1);
		return arr;

	}

	public static void main(String[] args) {
	
		String rev="choleswaraiah";
		char[] ch=rev.toCharArray();
		int start=0;
		int end=ch.length-1;
		char[] reverse = reverse(ch, start,end);
		
		String string = new String(reverse);
		
		System.out.println(string);

	}

}
