package com.java.psr;

import java.util.Arrays;
//https://www.vogella.com/tutorials/JavaDatastructureList/article.html
public class CustomArrayList<E> {

	private static final int INITIAL_CAPACITY = 10;
	int size = 0;
	private Object[] elementData = {};

	public CustomArrayList() {

		elementData = new Object[INITIAL_CAPACITY];
	}

	public void add(E e) {

		if (size == elementData.length) {

			ensusreCapacity();

		}
		elementData[size++] = e;
	}

	public Object remove(int index) {

		if (index < 0 || index >= size) {

			throw new IndexOutOfBoundsException("index problem" + index);

		}
		Object remove = elementData[index];

		for (int i = index; i < size - 1; i++) {

			elementData[i] = elementData[i + 1];
		}
		size--;
		return remove;
	}

	public E get(int index) {

		return (E) elementData[index];

	}

	private void ensusreCapacity() {

		int increaseSize = elementData.length * 2;
		Arrays.copyOf(elementData, increaseSize);

	}

	public void display() {

		for (int i = 0; i < size; i++) {

			System.out.println(elementData[i]);
		}
	}
	public static void main(String[] args) {
		
		CustomArrayList<Integer> cs = new CustomArrayList<>();
		
		cs.add(10);
		cs.add(20);
		cs.add(30);
		cs.add(40);
		cs.add(50);
		//cs.get(0);
		//System.out.println(cs.remove(1));
		cs.remove(2);
		cs.display();

	}
}
