package com.java.psr;

import java.util.Arrays;
import java.util.Comparator;

public class FindSecondHighestNumberFromArray {
	
	public static void main(String[] args) {
		
		int[] arr= {10,40,50,90,120,45,67,200,145};
		
		Integer integer = Arrays.stream(arr).boxed().sorted(Comparator.reverseOrder()).skip(1).findFirst().get();
		System.out.println(integer);
	}

}
