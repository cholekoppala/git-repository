package com.java.psr;

import java.util.stream.IntStream;

public class PermutationsFromString {
	
	public static void permuteString(String str,String expectOutPut) {
		
		if(str.length()==0) {
			
			System.out.println(expectOutPut+" ");
			return;
		}
		for(int i=0;i<str.length();i++) {
			char ch = str.charAt(i);
			String left_subString = str.substring(0,i);
			String right_substring = str.substring(i + 1);
			String result=left_subString+right_substring;
			permuteString(result, expectOutPut+ch);
		}
	}
	// java 8 stream example
		private static void stringPermuteAndPrint(String prefix, String input) {
			int n = input.length();
			if (n == 0) {
				System.out.print(prefix + " ");
			} else {
				IntStream.range(0, n).parallel().forEach(
						i -> stringPermuteAndPrint(prefix + input.charAt(i), input.substring(i + 1, n) + input.substring(0, i)));
			}
		}
	
	public static void main(String[] args) {
		
		String str="ABC";
		String expectOutPut="";
        System.out.print("\nAll possible strings are : ");
        permuteString(str, expectOutPut);

		// java8
        
        stringPermuteAndPrint("", "ABC");
		
	}

}
