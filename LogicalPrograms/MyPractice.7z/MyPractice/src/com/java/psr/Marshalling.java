package com.java.psr;

public class Marshalling {

	public static void main(String[] args) {
		
	}
}
