package com.java.psr;

public class MyApp {
	
	public static boolean hashsubsetsum(int[] arr,int len,int targetsum) {
		
		if(targetsum==0) {
			
			return true;
		}
		
		if(len==0) {
			
			return false;
		}
		
		if(arr[len-1]>targetsum) {
			
			return hashsubsetsum(arr, len-1, targetsum);
		}
		
		return hashsubsetsum(arr, len-1, targetsum) || hashsubsetsum(arr, len-1, targetsum-arr[len-1]);
	}

	public static void main(String[] args) {

		
		int arr[] = { 3, 34, 4, 12, 5, 2 };
		int targetsum=9;
		int len=0;
		
		boolean hashsubsetsum = hashsubsetsum(arr, len, targetsum);
		System.out.println(hashsubsetsum);


}
}