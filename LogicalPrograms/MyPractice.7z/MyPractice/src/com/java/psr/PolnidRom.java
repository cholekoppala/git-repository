/**
 * 
 */
package com.java.psr;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class PolnidRom {

	public static void main(String[] args) {

		int n = 12345;
		int remainder;
		int sum = 0;
		while (0<n) {

			remainder = n % 10;
			n = n / 10;
			sum = sum * 10 + remainder;
		}
		System.out.println(sum);
	}
}
