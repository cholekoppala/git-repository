package com.java.psr;

import java.util.Arrays;
import java.util.stream.IntStream;

public class GivenTwoArraysAreEqualOrNot {

	public static String twoArraysAreEqualOrNot(int[] arr1, int[] arr2) {

		Arrays.sort(arr1);
		Arrays.sort(arr2);

		boolean result = Arrays.equals(arr1, arr2);

		if (result) {

			return "Two arrays are equal";

		}
		return "Two arrays are not equal";

	}

	//java8
	public static boolean checkTwoArraysAreEqualOrNot(int[] a1, int[] a2) {
		
		Arrays.sort(a1);
		Arrays.sort(a2);
		if (a1 == a2) {
		  return true;
		}

		if (a1 == null || a2 == null || a1.length != a2.length) {
		  return false;
		}

		return IntStream.range(0, a1.length).allMatch(i -> a1[i]==a2[i]);
	}


	public static void main(String[] args) {

		int arr1[] = { 21, 6, 8, 9, 10, 5 };

		int arr2[] = { 10, 21, 5, 8, 6, 9 };

		String result = twoArraysAreEqualOrNot(arr1, arr2);

		System.out.println(result);
		
		boolean res = checkTwoArraysAreEqualOrNot(arr1, arr2);
		
		System.out.println(res);
	}

}
