package com.java.psr;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FindLengthOfEachiCityLenAndCityName {
	
	public static void main(String[] args) {
		
	Map<String, Integer> collect = Arrays.asList("Mumbai",
		"Munnar",
		"chennai",
		"Hyderabad").stream()
	.filter(s->s.startsWith("M") || s.startsWith("m"))
	.collect(Collectors.toMap(Function.identity(),String::length));
	
	System.out.println(collect);
	
	
		
		
	}

}
