package com.java.psr;

public class SubsetSumRecursion {

	public static boolean hashSubsetSum(int[] arr, int len,int targetSum) {

		if (targetSum == 0) {

			return true;
		}
		if (len == 0) {

			return false;
		}
		if (arr[len - 1] > targetSum) {

			return hashSubsetSum(arr,len - 1,targetSum);
		}
	
		return hashSubsetSum(arr,len - 1,targetSum) || hashSubsetSum(arr, len - 1,targetSum - arr[len - 1]);
	
	}

	public static void main(String[] args) {

		int arr[] = { 3, 34, 4, 12, 5, 2 };
        int targetsum = 9;
        int n = arr.length;

		boolean hashSubsetSum = hashSubsetSum(arr,n,targetsum);
		if(hashSubsetSum==true) {
			
			System.out.println("Given sum is hashsubsetsum>>>"+hashSubsetSum);
		}
		else {
			
			System.out.println("Given sum is not hashsubsetsum>>>"+hashSubsetSum);

		}

	}
}
