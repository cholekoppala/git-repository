package com.java.psr;

import java.util.Arrays;
import java.util.HashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class App {
	
	public static void main(String[] args) {
		
//		String input="The quick brown fox jumps right over the little lazy dog";
//		
//	
//		String collect = input 
//        .chars() 
//        .filter(ch -> (
//                'a' == ch || 'e' == ch || 'i' == ch || 'o' == ch || 'u' == ch || 
//                'A' == ch || 'E' == ch || 'I' == ch || 'O' == ch || 'U' == ch))
//        .mapToObj(c->(char)c).map(Object::toString).collect(Collectors.joining());
//		
//		System.out.println(collect);
		
		
		String  str="Rahul is employee of Epam company, rahul is from Pune, RAHUL! is good in algorithms";
		
		
		String[] words = str.split("\\s");
		HashMap<String,Integer> hm=new HashMap<>();
		for (String s : words) {
			String string = s.replaceAll("[,!]", "").toLowerCase();
			if(hm.get(string)!=null) {
				
				hm.put(string, hm.get(string)+1);
			}
			else {
				
				hm.put(string, 1);
			}
			
			
			
        
		}
		
		
		System.out.println(hm);

		
		
		
		
		
//      Stream.of(str.split(" ")).map(r->r.replaceAll("[,!]","").toLowerCase())
//      
//    .collect(Collectors.groupingBy(c->c,Collectors.counting())).entrySet()
//    .forEach(res->{
//    	
//    	if(res.getValue()>1) {
//    	
//    	String firstLettr=	res.getKey().substring(0,1).toUpperCase();
//    	String finalResp=firstLettr+res.getKey().substring(1,res.getKey().length());
//    		System.out.println(finalResp+" "+res.getValue());
//
//    	}
//    });




		String str1= "Swa$pn&il";
		
      String collect = str1.chars().mapToObj(c->(char)c)
      .map(r->new StringBuilder(r).reverse()).collect(Collectors.joining(""));
      
      System.out.println(collect);
      



    		
		
				
		
		

	}

}
