package com.java.psr;
public enum Gender {
    MALE, FEMALE
}