package com.java.psr;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FindDuplicateCharactersInString {
	
	public static void main(String[] args) {
		
		String str="choleswaraiah";
		
		String collect = str.chars().mapToObj(c->(char)c)
		.collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
		.entrySet().stream().filter(r->r.getValue()>1).map(x->x.getKey().toString()).collect(Collectors.joining(""));
				
		System.out.println(collect);
		
	 Character character = str.chars().mapToObj(c->(char)c).
			        collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
			        .entrySet().stream().max(Map.Entry.comparingByValue())
			        .map(x->x.getKey()).get();
		
	}

}
