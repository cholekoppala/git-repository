/**
 * 
 */
package com.java.psr;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class FindTheIndexOfTheFirstOccurance {
	
	 public static int strStr(String haystack, String needle) {

	        if(haystack.contains(needle)){
	            return haystack.indexOf(needle);
	        }
	    return -1;
	        
	    }
	
	public static void main(String[] args) {
		
		int strStr = strStr("choleswaraiahkoppala","koppala");
		
		System.out.println(strStr);
	}

}
