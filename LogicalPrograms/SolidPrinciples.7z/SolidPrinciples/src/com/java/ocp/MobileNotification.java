package com.java.ocp;

public class MobileNotification implements NotificationService {
	public void sendOTP(String medium) {
// write Logic using Twilio SMS API
	}

	public void sendTransactionNotification(String medium) {
	}
}