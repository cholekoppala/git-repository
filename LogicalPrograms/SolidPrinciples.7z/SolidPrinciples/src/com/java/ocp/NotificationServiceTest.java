package com.java.ocp;
public class NotificationServiceTest {

	public void sendOTP(String medium) {
		if(medium.equals("email")) {
			// write email related logic
		}
	}
    }
