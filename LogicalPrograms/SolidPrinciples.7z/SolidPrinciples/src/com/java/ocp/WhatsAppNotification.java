package com.java.ocp;

public class WhatsAppNotification implements NotificationService {
	public void sendOTP(String medium) {
// write Logic using whatsapp API
	}

	public void sendTransactionNotification(String medium) {
	}
}