package com.java.dip;

public interface BankCard {

    public void doTransaction(long amount);
}