/**
 * 
 */
package com.java.srp;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class TravelInsurance {
	
	public void getTravelInsuranceInfo(int ticketId) {
		// getting the Travel Insurance info
	}

}
