package com.java.srp;
class ReservationService {

	public String search(String source, String destination) {
		// do searchBuses
		return "Buses Found";
	}
	
	public String bookTicket(int numberOfSeats) {
		// booking the ticket
		return "Ticket Booked";
	}

}
