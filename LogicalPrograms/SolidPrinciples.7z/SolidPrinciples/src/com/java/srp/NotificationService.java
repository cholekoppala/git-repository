/**
 * 
 */
package com.java.srp;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class NotificationService {

	public void sendOTP(String medium) {

		if (medium.equals("email")) {
			// write email related logic
		}

	}
}
