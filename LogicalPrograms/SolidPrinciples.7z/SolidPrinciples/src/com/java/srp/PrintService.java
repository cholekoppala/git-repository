/**
 * 
 */
package com.java.srp;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class PrintService {

	public void printTickect() {
		// printing the Ticket
	}

}
