package com.java.isp;

public interface UPIPayments {

    public void payMoney();

    public void getScratchCard();


}