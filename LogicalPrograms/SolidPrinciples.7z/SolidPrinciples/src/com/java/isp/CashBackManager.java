package com.java.isp;

public interface CashBackManager {

    public void getCashBackAsCreditBalance();
}