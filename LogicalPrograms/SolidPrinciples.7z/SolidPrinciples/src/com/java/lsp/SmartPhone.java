/**
 * 
 */
package com.java.lsp;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class SmartPhone implements CallService,SMSService,AudioService,VideoService
{

	@Override
	public void playVideo(String videoFileName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void playMusic(String fileName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sendSMS() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void call() {
		// TODO Auto-generated method stub
		
	}
	

}
