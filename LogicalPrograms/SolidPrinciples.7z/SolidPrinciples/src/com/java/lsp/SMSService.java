/**
 * 
 */
package com.java.lsp;

/**
 * @author Koppala_Choleswaraia
 *
 */
public interface SMSService {

	public void sendSMS();

}
