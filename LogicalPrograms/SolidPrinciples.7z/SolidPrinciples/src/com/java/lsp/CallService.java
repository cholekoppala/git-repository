/**
 * 
 */
package com.java.lsp;

/**
 * @author Koppala_Choleswaraia
 *
 */
public interface CallService {
	
	public void call();


}
