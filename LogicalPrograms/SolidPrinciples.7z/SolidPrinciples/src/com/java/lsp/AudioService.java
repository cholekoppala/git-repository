/**
 * 
 */
package com.java.lsp;

/**
 * @author Koppala_Choleswaraia
 *
 */
public interface AudioService {
	
	public void playMusic(String fileName);

}
