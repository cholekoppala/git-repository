/**
 * 
 */
package com.java.lsp;

/**
 * @author Koppala_Choleswaraia
 *
 */
public interface VideoService {
	
	public void playVideo(String videoFileName);


}
