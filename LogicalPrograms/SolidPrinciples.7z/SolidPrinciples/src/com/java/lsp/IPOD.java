/**
 * 
 */
package com.java.lsp;

/**
 * @author Koppala_Choleswaraia
 *
 */
public class IPOD implements AudioService {

	@Override
	public void playMusic(String fileName) {
		// TODO Auto-generated method stub
		
	}

}
