package com.scb.bank.exception;

public class AccountIdNotFoundException extends RuntimeException {
	

	public AccountIdNotFoundException(String message) {
		super(message);
	}

}