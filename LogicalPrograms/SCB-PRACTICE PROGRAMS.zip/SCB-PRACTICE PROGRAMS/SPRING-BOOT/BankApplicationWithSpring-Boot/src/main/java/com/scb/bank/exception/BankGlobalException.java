package com.scb.bank.exception;
 
import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
 
@RestControllerAdvice
public class BankGlobalException
{
	//add exception handlers here
	@ExceptionHandler(CustomerIdNotFoundException.class)
	public ResponseEntity<?> handleCustomerIdNotFoundException(CustomerIdNotFoundException ex) 
	{
		System.out.println(ex);
		//RestErrorResponse response = new RestErrorResponse( ex.getMessage());
		//return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
		System.out.println(ex.getMessage());
		return new ResponseEntity<>( new RestErrorResponse(HttpStatus.NOT_FOUND.value(),ex.getMessage(),LocalDateTime.now()), HttpStatus.NOT_FOUND);
	}
	//add exception handler method for handling Exception class
	@ExceptionHandler(Exception.class)
	//@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ResponseEntity<?> handleException(Exception ex) {
		System.out.println(ex);
		// RestErrorResponse response = new RestErrorResponse( ex.getMessage());
		// return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<>(
				new RestErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), ex.getMessage(), LocalDateTime.now()),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	// add exception handler method for handling AccountIdNotFoundException class
	
	@ExceptionHandler(AccountIdNotFoundException.class)
	public ResponseEntity<?> handleAccountIdNotFoundException(AccountIdNotFoundException ex) {
		System.out.println(ex);
		// RestErrorResponse response = new RestErrorResponse( ex.getMessage());
		// return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(
				new RestErrorResponse(HttpStatus.NOT_FOUND.value(), ex.getMessage(), LocalDateTime.now()),
				HttpStatus.NOT_FOUND);
	}
	// add exception handler method for handling InsufficientFundsException class
	
	@ExceptionHandler(InsufficientFundsException.class)
	
	public ResponseEntity<?> handleInsufficientFundsException(InsufficientFundsException ex) {
		System.out.println(ex);
		// RestErrorResponse response = new RestErrorResponse( ex.getMessage());
		// return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		return new ResponseEntity<>(
				new RestErrorResponse(HttpStatus.BAD_REQUEST.value(), ex.getMessage(), LocalDateTime.now()),
				HttpStatus.BAD_REQUEST);
	}
}