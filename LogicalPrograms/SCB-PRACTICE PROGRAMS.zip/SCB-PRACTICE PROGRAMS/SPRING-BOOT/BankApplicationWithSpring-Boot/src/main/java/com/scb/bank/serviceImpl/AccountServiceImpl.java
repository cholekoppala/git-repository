package com.scb.bank.serviceImpl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.bank.dto.AccountWithCustomerDTO;
import com.scb.bank.entity.Account;
import com.scb.bank.entity.Customer;
import com.scb.bank.entity.Transaction;
import com.scb.bank.exception.AccountIdNotFoundException;
import com.scb.bank.exception.CustomerIdNotFoundException;
import com.scb.bank.exception.InsufficientFundsException;
import com.scb.bank.repository.AccountRepository;
import com.scb.bank.repository.CustomerRepository;
import com.scb.bank.repository.TransactionRepository;
import com.scb.bank.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private TransactionRepository transactionRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Account createAccount(Account account) {

		Customer customer = new Customer();
		customer.setCustomerName(account.getCustomer().getCustomerName());
		customer.setCustomerAddress(account.getCustomer().getCustomerAddress());
		customer.setCustomerContact(account.getCustomer().getCustomerContact());
		customerRepository.save(customer);
		return accountRepository.save(account);
	}

	@Override
	public Double balanceInquiry(Long accountId) {
		// TODO Auto-generated method stub
		Account account = accountRepository.findById(accountId).orElseThrow(() -> new AccountIdNotFoundException("Account with id " + accountId + " not found"));
		return account.getBalance();
	}

	@Override
	public void withdraw(Long accountId, Double amount) {

		Account account = accountRepository.findById(accountId).orElseThrow(() -> new AccountIdNotFoundException("Account with id " + accountId + " not found"));
		if (account.getBalance() >= amount) {
			account.setBalance(account.getBalance() - amount);
			accountRepository.save(account);

			Transaction transaction = new Transaction();
			transaction.setAccount(account);
			transaction.setType("WITHDRAW");
			transaction.setAmount(amount);
			transaction.setTransactionTime(LocalDateTime.now());
			transactionRepository.save(transaction);

		} else {
			throw new InsufficientFundsException("Insufficient funds");
		}

	}

	
	@Override
	public void deposit(Long accountId, Double amount) {

		Account account = accountRepository.findById(accountId).orElseThrow(() -> new AccountIdNotFoundException("Account with id " + accountId + " not found"));
		System.out.println("deposit account find by id" + account);
		account.setBalance(account.getBalance() + amount);
		System.out.println("deposit account updated" + account.getBalance());
		accountRepository.save(account);
		Transaction transaction = new Transaction();
		transaction.setAccount(account);
		transaction.setType("DEPOSIT");
		transaction.setAmount(amount);
		transaction.setTransactionTime(LocalDateTime.now());
		transactionRepository.save(transaction);
	}

	@Override
	public List<Transaction> getLast10Transactions(Long accountId) {
		// TODO Auto-generated method stub
		return transactionRepository.findTop10ByAccountIdOrderByTransactionTimeDesc(accountId);
	}

	@Override
	public void transfer(Long fromAccountId, Long toAccountId, Double amount) {

		Account fromAccount = accountRepository.findById(fromAccountId).orElseThrow(() -> new AccountIdNotFoundException("Account with id " + fromAccountId + " not found"));
		Account toAccount = accountRepository.findById(toAccountId).orElseThrow(() -> new AccountIdNotFoundException("Account with id " + toAccountId + " not found"));
		if (fromAccount.getBalance() >= amount) {
			fromAccount.setBalance(fromAccount.getBalance() - amount);
			toAccount.setBalance(toAccount.getBalance() + amount);
			accountRepository.save(fromAccount);
			accountRepository.save(toAccount);
			Transaction transaction = new Transaction();
			transaction.setAccount(fromAccount);
			transaction.setType("TRANSFER");
			transaction.setAmount(amount);
			transaction.setTransactionTime(LocalDateTime.now());
			transactionRepository.save(transaction);
		} else {
			throw new InsufficientFundsException("Insufficient funds");
		}
	}

	@Override
	public Customer createCustomer(Customer customer) {

		

		Customer data = customerRepository.save(customer);
		accountRepository.save(customer.getAccount());


		return data;
	}

	@Override
	public AccountWithCustomerDTO getCustomerId(Long accountId) {
		
		
		// TODO Auto-generated method stub
		
           Customer customer = customerRepository.findById(accountId)
                .orElseThrow(() -> new CustomerIdNotFoundException("Customer with id " + accountId + " not found"));

	
               Account account = accountRepository.findById(accountId)
            		                   .orElseThrow(() -> new AccountIdNotFoundException("Account with id " + accountId + " not found"));
               
               AccountWithCustomerDTO accountWithCustomerDTO = new AccountWithCustomerDTO();
               accountWithCustomerDTO.setCustomerAccountNumber(account.getAccountNumber());
               accountWithCustomerDTO.setCustomerAccountBalance(account.getBalance());
               accountWithCustomerDTO.setCustomerAccountHolderName(customer.getCustomerName());
               accountWithCustomerDTO.setCustomerAddress(customer.getCustomerAddress());
               accountWithCustomerDTO.setCustomerContact(customer.getCustomerContact());
               return accountWithCustomerDTO;
              
              
	}

}
