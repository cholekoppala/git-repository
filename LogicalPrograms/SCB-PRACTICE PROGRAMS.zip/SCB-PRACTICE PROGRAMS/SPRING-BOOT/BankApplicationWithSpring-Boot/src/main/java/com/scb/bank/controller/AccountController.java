/**
 * 
 */
package com.scb.bank.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.bank.dto.AccountWithCustomerDTO;
import com.scb.bank.entity.Customer;
import com.scb.bank.entity.Transaction;
import com.scb.bank.exception.RestErrorResponse;
import com.scb.bank.service.AccountService;

/**
 * 
 */

@CacheConfig(cacheNames = {"account","customer","transaction"})
@RestController
@RequestMapping("/account")
public class AccountController {

	@Autowired
	private AccountService accountService;

	// create account for customer	
	
	//cache implement in this controller methods
	
	@CachePut(key = "#customer")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	@PostMapping("/createCustomerAccount")
	public String createCustomer(@RequestBody Customer customer) {
		 Customer response = accountService.createCustomer(customer);
		 
		 return "customer account is created successfully Name "+response.getAccount().getAccountHolderName();
	}
	
	// deposit money to account number
	
    @Cacheable(value = "balancedeposit", key = "#accountNumber + '_' + #amount")
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@GetMapping("/deposit")
	public String deposit(@RequestParam Long accountNumber, @RequestParam double amount) {
		accountService.deposit(accountNumber, amount);
		return "Deposited successfully: " + amount + " to account number: " + accountNumber;
	}
	// withdraw money from account number

    @Cacheable(value = "withdrawcahe",key = "#accountNumber + '_' + #amount")
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@GetMapping("/withdraw")
	public String withdraw(@RequestParam Long accountNumber, @RequestParam double amount) {
		accountService.withdraw(accountNumber, amount);
		return "Withdrawn successfully : " + amount + " from account number: " + accountNumber;
	}

	// check balance of account number
     @Cacheable(value="balancecheck",key = "#accountNumber")
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@GetMapping("/balance/{accountNumber}")
	public String balanceInquiry(@PathVariable Long accountNumber) {
		Double balanceInquiry = accountService.balanceInquiry(accountNumber);

		return "Your balance is : " + balanceInquiry;
	}
	
	//show last 10 transactions
	
     @Cacheable(value = "transactionsCache", key = "#accountNumber")
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@GetMapping("/last10Transactions/{accountNumber}")
	public List<Transaction> showLast10Transactions(@PathVariable Long accountNumber) {
		
		return accountService.getLast10Transactions(accountNumber);
    }

//  transfer money from one account to another
    @Cacheable(value = "transferCache", key = "#fromAccountNumber + '_' + #toAccountNumber + '_' + #amount")
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@GetMapping("/transfer")
	public String transfer(@RequestParam Long fromAccountNumber, @RequestParam Long toAccountNumber,
			@RequestParam double amount) {
		accountService.transfer(fromAccountNumber, toAccountNumber, amount);
		return "Transfered successfully: " + amount + " from account number: " + fromAccountNumber
				+ " to account number: " + toAccountNumber;
	}
	
	// findby customerid and with globalexception handling
	
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@Cacheable(key = "#customerId")
	@GetMapping("/{customerId}")
	public ResponseEntity<Object> getCustomerById(@PathVariable Long customerId) {
		AccountWithCustomerDTO customerDetails = accountService.getCustomerId(customerId);
		
		if (customerDetails != null) {
			return new ResponseEntity<Object>(customerDetails,HttpStatus.OK);
		}
		return new ResponseEntity<Object>(new RestErrorResponse(200, "customer id not found>>>>"+customerId, LocalDateTime.now()), HttpStatus.OK);
	
	}
}
