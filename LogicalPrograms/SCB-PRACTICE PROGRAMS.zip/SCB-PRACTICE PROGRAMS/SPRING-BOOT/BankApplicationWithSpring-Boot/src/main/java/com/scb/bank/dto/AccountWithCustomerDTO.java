package com.scb.bank.dto;

public class AccountWithCustomerDTO {

	private String customerAccountNumber;
	private double customerAccountBalance;
	private String customerAccountHolderName;
	private String customerAddress;
	private String customerContact;

	public String getCustomerAccountNumber() {
		return customerAccountNumber;
	}

	public void setCustomerAccountNumber(String customerAccountNumber) {
		this.customerAccountNumber = customerAccountNumber;
	}

	public double getCustomerAccountBalance() {
		return customerAccountBalance;
	}

	public void setCustomerAccountBalance(double customerAccountBalance) {
		this.customerAccountBalance = customerAccountBalance;
	}

	public String getCustomerAccountHolderName() {
		return customerAccountHolderName;
	}

	public void setCustomerAccountHolderName(String customerAccountHolderName) {
		this.customerAccountHolderName = customerAccountHolderName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerContact() {
		return customerContact;
	}

	public void setCustomerContact(String customerContact) {
		this.customerContact = customerContact;
	}

}
