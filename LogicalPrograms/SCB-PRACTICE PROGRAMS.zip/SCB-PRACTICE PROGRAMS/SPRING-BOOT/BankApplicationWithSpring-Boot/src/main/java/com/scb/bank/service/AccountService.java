package com.scb.bank.service;

import java.util.List;

import com.scb.bank.dto.AccountWithCustomerDTO;
import com.scb.bank.entity.Account;
import com.scb.bank.entity.Customer;
import com.scb.bank.entity.Transaction;

public interface AccountService {
	
	public Account createAccount(Account account);
	public Customer createCustomer(Customer customer);
	public Double balanceInquiry(Long accountId);
    public void withdraw(Long accountId, Double amount);
    public void deposit(Long accountId, Double amount);
	public List<Transaction> getLast10Transactions(Long accountId);
    public void transfer(Long fromAccountId, Long toAccountId, Double amount);
	public AccountWithCustomerDTO getCustomerId(Long accountId);

}
