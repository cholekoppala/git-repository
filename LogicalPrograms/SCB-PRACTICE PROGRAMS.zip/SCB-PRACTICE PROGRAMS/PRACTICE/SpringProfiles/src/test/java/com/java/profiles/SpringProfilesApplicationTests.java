package com.java.profiles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProfilesApplicationTests {

	@Test
	void contextLoads() {
	}

}
