package com.java.bank.service;

public interface Bank {
    String getBankName();
}
