package com.java.profiles;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.java.bank.config.BankConfig;
import com.java.bank.service.Bank;

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan(basePackages = "com.java.bank")
public class SpringProfilesApplication implements CommandLineRunner {

	@Autowired
	private Bank bank;

	public static void main(String[] args) {

		SpringApplication.run(SpringProfilesApplication.class, args);

	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		String bankName = bank.getBankName();
		System.out.println(bankName);

	}

}
