package com.java.bank.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.java.bank.service.Bank;
import com.java.bank.service.impl.HDFCBank;
import com.java.bank.service.impl.ICICIBank;
import com.java.bank.service.impl.SBIBank;

@Configuration
public class BankConfig {
	
    @Value("${bank.test}")
	private String testprofiledata;

    @Bean
    @Profile("dev")
    public Bank devSBI() {
        return new SBIBank();
    }

    @Bean
    @Profile("prod")
    public Bank prodICIC() {
        return new ICICIBank();
    }

    @Bean
    @Profile("test")
    public Bank testHDFC() {
    	System.out.println(testprofiledata);
        return new HDFCBank();
    }
}
