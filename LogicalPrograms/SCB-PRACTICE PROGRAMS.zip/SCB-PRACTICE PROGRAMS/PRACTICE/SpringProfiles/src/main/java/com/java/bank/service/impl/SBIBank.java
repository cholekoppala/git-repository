package com.java.bank.service.impl;

import com.java.bank.service.Bank;

public class SBIBank implements Bank {

    @Override
    public String getBankName() {
        return "SBI Bank";
    }
}
