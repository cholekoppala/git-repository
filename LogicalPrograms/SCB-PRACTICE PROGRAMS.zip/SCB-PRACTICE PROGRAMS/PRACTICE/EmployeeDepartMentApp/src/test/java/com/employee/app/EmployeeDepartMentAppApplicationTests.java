package com.employee.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeDepartMentAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
