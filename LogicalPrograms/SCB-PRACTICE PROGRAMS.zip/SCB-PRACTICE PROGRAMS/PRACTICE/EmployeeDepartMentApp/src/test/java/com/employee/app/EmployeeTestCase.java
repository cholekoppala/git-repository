package com.employee.app;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.employee.controller.EmployeeController;
import com.employee.entity.Employee;
import com.employee.exception.EmployeeIdNotFoundException;
import com.employee.service.EmployeeService;

@ExtendWith(MockitoExtension.class)
public class EmployeeTestCase {

	@Mock
	private EmployeeService employeeService;

	@InjectMocks
	private EmployeeController employeeController;

	@Test
	public void addEmployeTestcase() {

		Employee employee = new Employee();
		int empId = 1;
		employee.setId(empId);
		employee.setEmpName("chole");
		employee.setEmpDepartment("hr");
		
		when(employeeService.addEmployees(employee)).thenReturn(employee);

		Employee empResp = employeeController.addEmployees(employee);

		assertEquals("chole", empResp.getEmpName());

		//verify(employeeService, times(1)).addEmployees(employee);

	}

	@Test
	public void testCaseGetBydeptName() {

		List<Employee> ls = new ArrayList<>();

		Employee employee = new Employee();
		employee.setId(1);
		employee.setEmpName("chole");
		employee.setEmpDepartment("hr");

		Employee employee1 = new Employee();
		employee1.setId(2);
		employee1.setEmpName("koppala");
		employee1.setEmpDepartment("hr");

		Employee employee2 = new Employee();
		employee2.setId(3);
		employee2.setEmpName("ravi");
		employee2.setEmpDepartment("dev");

		ls.add(employee);
		ls.add(employee1);
		ls.add(employee2);

		String dept = "hr";

		List<Employee> deptList = ls.stream().filter(emp -> emp.getEmpDepartment().equals(dept))
				.collect(Collectors.toList());
		Mockito.when(employeeService.departmentByName(dept)).thenReturn(deptList);

		List<Employee> list = employeeController.getDepartMentByName(dept);

		assertEquals(2, list.size());

	}
	
	@Test
	public void testGetEmployeeById()
	{
		Integer empId=1;
		Employee employees = new Employee();
		employees.setId(empId);
		employees.setEmpName("cholekoppala");
		employees.setEmpDepartment("fs");
		
		when(employeeService.getEmployeeId(empId)).thenReturn(employees);
		Employee employee = employeeController.getEmployeeById(empId);
		
		assertEquals(1, employee.getId());
		assertEquals("cholekoppala", employee.getEmpName());
		assertEquals("fs", employee.getEmpDepartment());
		
	}
    @Test
    public void testGetEmployeeById_employeeNotFound() throws EmployeeIdNotFoundException {
        int empId = 1;

		when(employeeService.getEmployeeId(empId)).thenReturn(null);

        employeeController.getEmployeeById(empId);

    }

	@Test
	public void testGetAllEmployees() {
		
		List<Employee> ls = new ArrayList<>();

		Employee employee = new Employee();
		employee.setId(1);
		employee.setEmpName("chole");
		employee.setEmpDepartment("hr");

		Employee employee1 = new Employee();
		employee1.setId(2);
		employee1.setEmpName("koppala");
		employee1.setEmpDepartment("hr");

		Employee employee2 = new Employee();
		employee2.setId(3);
		employee2.setEmpName("ravi");
		employee2.setEmpDepartment("dev");

		ls.add(employee);
		ls.add(employee1);
		ls.add(employee2);
		
		when(employeeService.getAllEmployees()).thenReturn(ls);
		List<Employee> allEmployees = employeeController.getAllEmployees();
		assertEquals(3, allEmployees.size());
	}

	@Test
	public void testUpdateEmployees() {
		
		Integer empId=1;
		
		Employee updatedEmployee = new Employee();
		updatedEmployee.setId(empId);
		updatedEmployee.setEmpName("cholekoppala");
		updatedEmployee.setEmpDepartment("fs");

		Employee savedEmployee = new Employee();
		savedEmployee.setId(empId);
		savedEmployee.setEmpName("cholekoppala");
		savedEmployee.setEmpDepartment("fs");
		
        Mockito.when(employeeService.updateEmployee(empId, updatedEmployee)).thenReturn(savedEmployee);

        Employee returnedEmployee = employeeController.updateEmployee(empId, updatedEmployee);

        assertEquals("cholekoppala", returnedEmployee.getEmpName());
        assertEquals("fs", returnedEmployee.getEmpDepartment());

	}
	@Test
	public void testDeleteEmpId() {

		Integer empId = 1;

		employeeController.deleteEmpById(empId);

		verify(employeeService, times(1)).deleteEmpId(empId);

	}
	
	
}
