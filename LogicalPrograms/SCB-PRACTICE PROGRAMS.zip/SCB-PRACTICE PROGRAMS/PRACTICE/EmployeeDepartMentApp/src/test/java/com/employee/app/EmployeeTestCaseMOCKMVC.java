package com.employee.app;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.employee.controller.EmployeeController;
import com.employee.entity.Employee;
import com.employee.service.EmployeeService;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@AutoConfigureMockMvc
public class EmployeeTestCaseMOCKMVC {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private EmployeeService employeeService;

	@InjectMocks
	private EmployeeController employeeController;

	@Autowired
	private ObjectMapper objectMapper;

	@BeforeEach
	public void setUp() {

		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testSaveEmloyeeDetails() throws Exception {

		Employee employeeToSave = new Employee();
		employeeToSave.setId(1);
		employeeToSave.setEmpName("chole");
		employeeToSave.setEmpDepartment("hr");

		Employee savedEmployee = new Employee();
		savedEmployee.setId(null);
		savedEmployee.setEmpName("chole");
		savedEmployee.setEmpDepartment("hr");

		String employeeJson = objectMapper.writeValueAsString(employeeToSave);

		when(employeeService.addEmployees(Mockito.any(Employee.class))).thenReturn(savedEmployee);

		mockMvc.perform(MockMvcRequestBuilders.post("/addEmployees")
				.contentType(MediaType.APPLICATION_JSON)
				.content(employeeJson)).andExpect(status().isOk())
		        .andExpect(jsonPath("$.empName").value("chole"))
				.andExpect(jsonPath("$.empDepartment").value("hr"));

	}

	@Test
	public void testGetEmployeeById() throws Exception {

		Integer empId = 1;

		Employee employee = new Employee();
		employee.setId(empId);
		employee.setEmpName("chole");
		employee.setEmpDepartment("hr");

		when(employeeService.getEmployeeId(empId)).thenReturn(employee);

		mockMvc.perform(MockMvcRequestBuilders.get("/{empId}", empId)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.empName").value("chole"))
				.andExpect(jsonPath("$.empDepartment").value("hr"));
	}

	@Test
	public void testGetAllEmployees() throws Exception {

		List<Employee> ls = new ArrayList<>();

		Employee employee = new Employee();
		employee.setId(1);
		employee.setEmpName("chole");
		employee.setEmpDepartment("hr");

		Employee employee1 = new Employee();
		employee1.setId(2);
		employee1.setEmpName("koppala");
		employee1.setEmpDepartment("hr");

		Employee employee2 = new Employee();
		employee2.setId(3);
		employee2.setEmpName("ravi");
		employee2.setEmpDepartment("dev");

		ls.add(employee);
		ls.add(employee1);
		ls.add(employee2);

		when(employeeService.getAllEmployees()).thenReturn(ls);

		mockMvc.perform(MockMvcRequestBuilders.get("/empList")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].empName").value("chole"))
				.andExpect(jsonPath("$[1].empName").value("koppala"));

	}

	@Test
	public void testUpdateEmployeeById() throws Exception {

		int empId = 1;

		Employee updateEmployee = new Employee();
		updateEmployee.setId(empId);
		updateEmployee.setEmpName("chole");
		updateEmployee.setEmpDepartment("hr");

		Employee savedEmployee = new Employee();
		savedEmployee.setId(empId);
		savedEmployee.setEmpName("chole");
		savedEmployee.setEmpDepartment("hr");

		String updatedEmployeeJson = objectMapper.writeValueAsString(updateEmployee);

        when(employeeService.updateEmployee(eq(empId), any(Employee.class))).thenReturn(savedEmployee);

	            mockMvc.perform(MockMvcRequestBuilders.put("/updateEmployee/{empId}", empId)
				.contentType(MediaType.APPLICATION_JSON)
				.content(updatedEmployeeJson))
		        .andExpect(status().isOk())
		        .andExpect(jsonPath("$.empName").value("chole"))
		        .andExpect(jsonPath("$.empDepartment").value("hr"));
	}

	@Test
	public void testDeleteEmployeeById() throws Exception {

		Integer empId = 1;

		mockMvc.perform(MockMvcRequestBuilders.delete("/delete/{empId}", empId))
		.andExpect(status().isOk());

		Mockito.verify(employeeService, times(1)).deleteEmpId(empId);

	}

}
