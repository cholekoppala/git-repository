package com.employee.dept.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.dept.entity.Department;
import com.employee.dept.repo.DepartmentRepository;

@Service
public class DepartmentService {
	
	@Autowired
	private DepartmentRepository departmentRepository;
	
	public Department addDepartmet(Department department) {
		
		return departmentRepository.save(department);
		
	}
	
	public List<Department> getAllDepartement(){
		
		return departmentRepository.findAll();
	}
	
	public Department getDepartmentById(Integer deptId)
	{
		
		return departmentRepository.findById(deptId).get();
	}
}
