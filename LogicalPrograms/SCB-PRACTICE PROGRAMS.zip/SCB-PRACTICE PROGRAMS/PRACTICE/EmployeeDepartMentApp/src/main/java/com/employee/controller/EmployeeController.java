package com.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.employee.entity.Employee;
import com.employee.service.EmployeeService;

@RestController
public class EmployeeController {
	
	
	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping("/addEmployees")
	public Employee addEmployees(@RequestBody Employee employee) {
		
		return employeeService.addEmployees(employee);
		
	}
	
	@GetMapping("/dept/{deptName}")
	public List<Employee> getDepartMentByName(@PathVariable String deptName){
		
		return employeeService.departmentByName(deptName);
	}
	
	@PutMapping("/updateEmployee/{empId}")
	public Employee updateEmployee(@PathVariable Integer empId,@RequestBody Employee updateEmployee) {
		
		return employeeService.updateEmployee(empId, updateEmployee);
	}
	
	@DeleteMapping("/delete/{empId}")
	public void deleteEmpById(@PathVariable Integer empId) {
		
		 employeeService.deleteEmpId(empId);
	}
	
	@GetMapping("/{empId}")
	public Employee getEmployeeById(@PathVariable Integer empId) {
		
		return employeeService.getEmployeeId(empId);
	}
	
	@GetMapping("/empList")
	public List<Employee> getAllEmployees(){
		
		return employeeService.getAllEmployees();
	}

}
 