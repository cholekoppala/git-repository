package com.employee.projection;

public class EmployeeClassProjection {

	private Integer id;
	private String empName;
	private String empDepartment;

	public EmployeeClassProjection(Integer id, String empName, String empDepartment) {
		super();
		this.id = id;
		this.empName = empName;
		this.empDepartment = empDepartment;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpDepartment() {
		return empDepartment;
	}

	public void setEmpDepartment(String empDepartment) {
		this.empDepartment = empDepartment;
	}

}
