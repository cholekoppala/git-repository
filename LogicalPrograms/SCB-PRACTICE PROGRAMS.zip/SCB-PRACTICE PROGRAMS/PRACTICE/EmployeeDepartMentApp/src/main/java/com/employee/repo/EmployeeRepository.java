package com.employee.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.employee.entity.Employee;
import com.employee.projection.EmployeeClassProjection;
import com.employee.projection.EmployeeProjection;

@Repository
public interface EmployeeRepository  extends JpaRepository<Employee, Integer>{

	@Query("SELECT e FROM Employee e WHERE e.empDepartment = :deptName")
    List<Employee> findByDepartmentName(@Param("deptName") String deptName);
	
	// interface based projection 
	//@Query("SELECT e.id AS id, e.empDepartment AS empDepartment, e.empName AS empName FROM Employee e WHERE e.empDepartment = :deptName")
  //  List<EmployeeProjection> findByDepartmentName(@Param("deptName") String deptName);
	
	// class based projection
//	 @Query("SELECT new com.employee.projection.EmployeeClassProjection(e.id, e.empName, e.empDepartment) " +
//	           "FROM Employee e WHERE e.empDepartment = :deptName")
//	    List<EmployeeClassProjection> findByDepartmentName(@Param("deptName") String deptName);

}
