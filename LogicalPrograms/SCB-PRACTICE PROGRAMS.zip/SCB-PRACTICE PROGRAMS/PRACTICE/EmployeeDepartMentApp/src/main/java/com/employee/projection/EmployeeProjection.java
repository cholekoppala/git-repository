package com.employee.projection;

public interface EmployeeProjection {

	Integer getId();

	public String getEmpName();

	String getEmpDepartment();

//	Double getEmpSal();

}