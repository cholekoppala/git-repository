package com.employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.employee.entity.Employee;
import com.employee.exception.EmployeeIdNotFoundException;
import com.employee.repo.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	public Employee addEmployees(Employee employee) {

		return employeeRepository.save(employee);
	}

	public List<Employee> departmentByName(String deptName) {

		return employeeRepository.findByDepartmentName(deptName);

	}

	public Employee updateEmployee(Integer empId, Employee updatedEmployee) {

		Optional<Employee> existingEmployee = employeeRepository.findById(empId);

		if (existingEmployee.isPresent()) {
			Employee emp = existingEmployee.get();
			emp.setEmpName(updatedEmployee.getEmpName());
			emp.setEmpDepartment(updatedEmployee.getEmpDepartment());
			return employeeRepository.save(emp);
		}
		return null;
	}
	
	public Employee getEmployeeId(@PathVariable Integer empId) {
		
		return employeeRepository.findById(empId).orElseThrow(()->new EmployeeIdNotFoundException("emp id not fount"));
		
	}

	public void deleteEmpId(@PathVariable Integer empId) {

		employeeRepository.deleteById(empId);
	}

	public List<Employee> getAllEmployees() {

		return employeeRepository.findAll();
	}

}
