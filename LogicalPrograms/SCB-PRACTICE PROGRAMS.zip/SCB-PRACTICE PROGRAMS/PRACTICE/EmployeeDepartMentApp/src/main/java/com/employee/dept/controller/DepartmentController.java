package com.employee.dept.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.dept.entity.Department;
import com.employee.dept.service.DepartmentService;

@RestController
@RequestMapping("/dept")
public class DepartmentController {

	@Autowired
	private DepartmentService departmentService;

	@PostMapping("/addDepartment")
	public Department addDepartmentDetails(@RequestBody Department department) {

		return departmentService.addDepartmet(department);
	}

	@GetMapping("/deptAll")
	public List<Department> getAllDepartments() {

		return departmentService.getAllDepartement();
	}

	@GetMapping("/{deptId}")
	public Department getDeptById(Integer deptId)

	{
		return departmentService.getDepartmentById(deptId);

	}
}
