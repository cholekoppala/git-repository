package com.employee.exception;

public class EmployeeIdNotFoundException extends RuntimeException {
	
	
	public EmployeeIdNotFoundException(String msg) {
		
		super(msg);
	}

}
