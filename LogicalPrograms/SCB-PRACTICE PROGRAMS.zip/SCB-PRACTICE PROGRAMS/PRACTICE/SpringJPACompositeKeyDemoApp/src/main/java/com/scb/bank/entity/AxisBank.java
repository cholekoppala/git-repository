package com.scb.bank.entity;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "Axis_Bank")
public class AxisBank {

//	@Id
//	\@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private int bankid;
	private String bankname;
	private String branch;
	private float minbalance;

	@EmbeddedId
	private AxisBankUniqueIds id;

	public String getBankname() {
		return bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public float getMinbalance() {
		return minbalance;
	}

	public void setMinbalance(float minbalance) {
		this.minbalance = minbalance;
	}

	public AxisBankUniqueIds getId() {
		return id;
	}

	public void setId(AxisBankUniqueIds id) {
		this.id = id;
	}

}
