/**
 * 
 */
package com.scb.bank.entity;

import jakarta.persistence.Embeddable;

/**
 * 
 */
@Embeddable
public class AxisBankUniqueIds {

	private String ifsc;
	private int bankid;

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public int getBankid() {
		return bankid;
	}

	public void setBankid(int bankid) {
		this.bankid = bankid;
	}

}
