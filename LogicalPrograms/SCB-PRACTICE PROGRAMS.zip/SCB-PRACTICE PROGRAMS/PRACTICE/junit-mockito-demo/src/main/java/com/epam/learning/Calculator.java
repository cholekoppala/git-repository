package com.epam.learning;

public class Calculator {

    /* This method returns sum of two integer numbers*/
    public int sumOfTwoNumbers(int n1,int n2){
        return n1+n2;
    }

    /* This method returns multiplication of two integer numbers*/
    public int multiplicationOfTwoNumbers(int n1,int n2){
        return n1*n2;
    }
    
    
}
