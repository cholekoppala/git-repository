package com.epam.practice;

public class MyMathUtils {

	private final MyCalculator calculator;

	public MyMathUtils(MyCalculator calculator) {

		this.calculator = calculator;
	}

	public int sumOfTwoNumbers(int n1, int n2) {

		return calculator.sumOfTwoNumbers(n1, n2);
	}

	public int multificationTwoNumbers(int n1, int n2) {

		return calculator.multificationTwoNumbers(n1, n2);
	}

	public static boolean isEven(int no) {

		return no % 2 == 0;

	}

	private boolean isOdd(int no) {

		return no % 2 != 0;
	}
	
	public final String finalMsg() {
		
		return "hello world";
	}

}
