package com.epam.practice;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.epam.learning.Calculator;

public class MyCalculatorTestCase {

	private Calculator calculator;

	private List<Integer> intList;

	@Before
	public void setUp() {
		calculator = new Calculator();
		intList = new ArrayList<>();
		System.out.println("setUP executed");
	}

	@Test
	public void testSumofTwoNumbers() {

		int result = calculator.sumOfTwoNumbers(2, 3);
		intList.add(result);
		assertEquals(5, result);
	}

	@Test
	public void testMultificationTwoNumbers() {

		int result = calculator.multiplicationOfTwoNumbers(2, 3);

		intList.add(result);
		assertEquals(6, result);

	}

	@Test
	public void tearDown() {

		System.out.println(intList);

		intList.clear();

		System.out.println("teardown executed");

	}

}
