package com.epam.practice;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class MyMathUtilsTestCase {

	@Mock
	private MyCalculator calculator;

	@InjectMocks
	private MyMathUtils mathUtils;

	private static List<Integer> intList;

	@BeforeClass
	public static void setUP() {

		intList = new ArrayList<>();
		System.out.println("setUP Executed");

	}

	@Test
	public void testSumofTwoNumbers() {

		when(calculator.sumOfTwoNumbers(2, 3)).thenReturn(5);
		int result = mathUtils.sumOfTwoNumbers(2, 3);
		intList.add(result);
		assertEquals(5, result);
	}

	@Test
	public void testMultiflicationofTwoNumbers() {

		when(calculator.multificationTwoNumbers(2, 3)).thenReturn(5);
		int result = mathUtils.multificationTwoNumbers(2, 3);

		assertEquals(5, result);
	}

	public void testDown() {

		System.out.println(intList);
		intList.clear();
		System.out.println();
	}

}
