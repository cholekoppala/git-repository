package com.epam.learning;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
public class CalculatorTest {
    private Calculator calculator;
    private List<Integer> integerList;

    /*  @Before and @BeforeEach  serve same purpose
     *  @Before is from Junit4 while @BeforeEach is from Junit5
     *  The method annotated with @Before or @BeforeEach is nonstatic
     *  It executes once before each test method execution
     *  Lifecycle: setUp-->each test method-->tearDown
     * */

    @Before
    public void setUp() {
        calculator=new Calculator();
        integerList=new ArrayList<>();
        System.out.println("setUp executed");
    }

    @Test
    public void sumOfTwoNumbers() {
        //Set expectation
        int result = calculator.sumOfTwoNumbers(2, 3);

        //Add result to arrayList
        integerList.add(result);

        //Asset the response
        Assert.assertEquals(5,result);

    }

    @Test
    public void multiplicationOfTwoNumbers() {
        //Set expectation
        int result = calculator.multiplicationOfTwoNumbers(2, 3);

        //Add result to arrayList
        integerList.add(result);

        //Asset the response
        Assert.assertEquals(6,result);
    }

    @After
    public void tearDown() {
        System.out.println(integerList);
        integerList.clear();
        System.out.println("tearDown executed");

    }
    
    
}