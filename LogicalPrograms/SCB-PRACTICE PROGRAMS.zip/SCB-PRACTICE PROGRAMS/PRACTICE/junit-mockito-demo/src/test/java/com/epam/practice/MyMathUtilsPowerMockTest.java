package com.epam.practice;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

@RunWith(PowerMockRunner.class)
@PrepareForTest(MyMathUtils.class)
public class MyMathUtilsPowerMockTest {

	// static method mock

	@Test
	public void testShouldReturnTrueOrFalseGivenEvenNumber() {
		PowerMockito.mockStatic(MyMathUtils.class);
		PowerMockito.when(MyMathUtils.isEven(2)).thenReturn(true);
		boolean result = MyMathUtils.isEven(2);

		assertTrue(result);

	}

	// private method

	@Test
	public void testshouldReturnTrueOrFalseGivenOddNumber() throws Exception {

		MyMathUtils mock = PowerMockito.mock(MyMathUtils.class);
		PowerMockito.doReturn(true).when(mock, "isOdd", 3);
		boolean result = Whitebox.invokeMethod(mock, "isOdd", 3);
		assertTrue(result);
	}

	@Test
	public void testFinalstring() {
		
		MyMathUtils mock = PowerMockito.mock(MyMathUtils.class);
		Mockito.when(mock.finalMsg()).thenReturn("hello world");
		String result = mock.finalMsg();
		
		assertEquals(result, "hello world");
		

	}

}
