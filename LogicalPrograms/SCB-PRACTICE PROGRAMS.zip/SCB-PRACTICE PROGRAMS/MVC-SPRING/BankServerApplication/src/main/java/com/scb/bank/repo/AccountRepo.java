package com.scb.bank.repo;

import java.util.List;

import com.scb.bank.dto.AccountWithCustomerDTO;
import com.scb.bank.entity.Account;
import com.scb.bank.entity.Customer;
import com.scb.bank.entity.Transaction;

public interface AccountRepo {
	
	public Account createAccount(AccountWithCustomerDTO account);
	public Customer createCustomer(Customer customer);
	public Double balanceInquiry(Integer accountId);
    public void deposit(Long accountId, Double amount);
    public void withdraw(Long accountId, Double amount);
	public List<Transaction> getLast10Transactions(Long accountId);

	// fund transfer method to transfer money from one account to another account
	
	public void fundTransfer(Long fromAccountId, Long toAccountId, Double amount);


}
