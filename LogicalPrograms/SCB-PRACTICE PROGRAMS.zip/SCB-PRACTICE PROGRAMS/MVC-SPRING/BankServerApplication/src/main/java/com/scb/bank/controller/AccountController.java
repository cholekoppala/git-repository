/**
 * 
 */
package com.scb.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.scb.bank.dto.AccountWithCustomerDTO;
import com.scb.bank.dto.TransferFormDTO;
import com.scb.bank.entity.Account;
import com.scb.bank.entity.Transaction;
import com.scb.bank.exception.InsufficientFundsException;
import com.scb.bank.service.AccountService;

import jakarta.validation.Valid;

/**
 * 
 */
@Controller
public class AccountController {

	@Autowired
	private AccountService accountService;

	// show register form
	@GetMapping("/register")
	public String showForm(Model model) {
		AccountWithCustomerDTO account = new AccountWithCustomerDTO();
		model.addAttribute("account", account);

		return "registeraccount_form";

	}

// register account
	@RequestMapping(method = RequestMethod.POST, path = "/register")
	public String submitForm(@Valid @ModelAttribute("account") AccountWithCustomerDTO account,
			BindingResult bindingResult)

	{
		if (bindingResult.hasErrors()) {
			System.out.println("Total count of errors are = " + bindingResult.getErrorCount());
			return "registeraccount_form";
		}
		System.out.println(account);
		accountService.createAccount(account);

		return "registeraccount_success";
	}

	// show balace enquiry form

	@GetMapping("/balanceInquiry")
	public String showBalanceForm(Model model) {
		model.addAttribute("account", new Account());
		return "balanceinquiry";
	}

	// balance enquiry
	@PostMapping("/balanceInquiry")
	public String balance(@ModelAttribute Account account, Model model) {
		Double balance = accountService.balanceInquiry(account.getId());
		model.addAttribute("message", "Balance is " + balance);
		return "result";
	}

	// show deposit form
	@GetMapping("/deposit")
	public String showDepositForm(Model model) {
		model.addAttribute("transaction", new Transaction());
		return "deposit";
	}

	// deposit
	@PostMapping("/deposit")
	public String deposit(@ModelAttribute Transaction transaction, Model model) {
		accountService.deposit(transaction.getAccountId(), transaction.getAmount());
		model.addAttribute("message", "Deposit successful");
		return "result";
	}

	// show withdraw form
	@GetMapping("/withdraw")
	public String showWithdrawForm(Model model) {
		model.addAttribute("transaction", new Transaction());
		return "withdraw";
	}

	// withdraw
	@PostMapping("/withdraw")
	public String withdraw(@ModelAttribute Transaction transaction, Model model) {
		try {
			accountService.withdraw(transaction.getAccountId(), transaction.getAmount());
			model.addAttribute("message", "Withdrawal successful");
		} catch (InsufficientFundsException e) {
			model.addAttribute("message", e.getMessage());
		}
		return "result";
	}

	// show last 10 transactions

	@GetMapping("/last10transactions")
	public String showLast10Transactions(Model model) {
		model.addAttribute("transactions", new Transaction());
		return "last10transactionsForm";
	}

	// last 10 transactions
	@PostMapping("/last10transactions")
	public String showLast10Transactions(@ModelAttribute Transaction transactions, Model model) {
		try {
			List<Transaction> last10Transactions = accountService.getLast10Transactions(transactions.getAccountId());
			model.addAttribute("transactions", last10Transactions);

		} catch (InsufficientFundsException e) {
			// model.addAttribute("message", e.getMessage());
		}
		return "last10transactionssucess";
	}

	// show last 10 transactions
	@GetMapping("/transfer")
	public String transferFunds(Model model) {
		model.addAttribute("transfer", new TransferFormDTO());
		return "transferForm";
	}

	// transfer funds
	@RequestMapping(method = RequestMethod.POST, path = "/transfer")
	public String transferFunds(@Valid @ModelAttribute("transfer") TransferFormDTO transfer,
			BindingResult bindingResult)

	{
		if (bindingResult.hasErrors()) {
			System.out.println("Total count of errors are = " + bindingResult.getErrorCount());
			return "transferForm";
		}
		System.out.println(transfer);
		accountService.fundTransfer(transfer.getFromAccountId(), transfer.getToAccountId(), transfer.getAmount());

		return "transfersuccess";
	}

}
