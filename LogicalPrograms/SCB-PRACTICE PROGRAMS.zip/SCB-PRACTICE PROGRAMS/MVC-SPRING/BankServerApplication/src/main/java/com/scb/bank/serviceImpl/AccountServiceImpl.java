package com.scb.bank.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.bank.dto.AccountWithCustomerDTO;
import com.scb.bank.entity.Account;
import com.scb.bank.entity.Customer;
import com.scb.bank.entity.Transaction;
import com.scb.bank.repo.AccountRepo;
import com.scb.bank.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService {
	
	@Autowired
	private AccountRepo accountRepo;
	
	@Override
	public Account createAccount(AccountWithCustomerDTO account) {
		return accountRepo.createAccount(account);
	}

	@Override
	public void withdraw(Long accountId, Double amount) {
		
		accountRepo.withdraw(accountId, amount);
		
	}

	@Override
	public void deposit(Long accountId, Double amount) {
		
		accountRepo.deposit(accountId, amount);
		
	}

	@Override
	public Double balanceInquiry(Integer accountId) {
		
		return accountRepo.balanceInquiry(accountId);
	}

	@Override
	public List<Transaction> getLast10Transactions(Long accountId) {
		// TODO Auto-generated method stub
		return accountRepo.getLast10Transactions(accountId);
	}

	@Override
	public void fundTransfer(Long fromAccountId, Long toAccountId, Double amount) {
		// TODO Auto-generated method stub
		accountRepo.fundTransfer(fromAccountId, toAccountId, amount);
	}

	@Override
	public Customer createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return accountRepo.createCustomer(customer);
	}

}
