package com.scb.bank.exception;
 
import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
 
@RestControllerAdvice
public class CustomerIdNotFoundGlobalException
{
	//add exception handlers here
	@ExceptionHandler(CustomerIdNotFoundException.class)
	public ResponseEntity<?> handleCustomerIdNotFoundException(CustomerIdNotFoundException ex) 
	{
		System.out.println(ex);
		//RestErrorResponse response = new RestErrorResponse( ex.getMessage());
		//return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
		System.out.println(ex.getMessage());
		return new ResponseEntity<>( new RestErrorResponse(HttpStatus.NOT_FOUND.value(),ex.getMessage(),LocalDateTime.now()), HttpStatus.NOT_FOUND);
	}
	//add exception handler method for handling Exception class
	@ExceptionHandler(Exception.class)
	//@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ResponseEntity<?> handleException(Exception ex) {
		System.out.println(ex);
		// RestErrorResponse response = new RestErrorResponse( ex.getMessage());
		// return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<>(
				new RestErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), ex.getMessage(), LocalDateTime.now()),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}
}