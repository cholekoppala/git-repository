package com.scb.bank.repoimpl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.scb.bank.dbconfig.DBUtil;
import com.scb.bank.dto.AccountWithCustomerDTO;
import com.scb.bank.entity.Account;
import com.scb.bank.entity.Customer;
import com.scb.bank.entity.Transaction;
import com.scb.bank.exception.InsufficientFundsException;
import com.scb.bank.repo.AccountRepo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

@Service
public class AccountRepoImpl implements AccountRepo {

	private static EntityManager manager;

	public AccountRepoImpl() {
		manager = DBUtil.getManager();
	}

	public void beginTransaction() {
		manager.getTransaction().begin();
	}

	public void commitTransaction() {
		manager.getTransaction().commit();
	}

	@Override
	public Account createAccount(AccountWithCustomerDTO account) {
		beginTransaction();
		Account account1 = new Account();
		account1.setAccountNumber(account.getCustomerAccountNumber());
		account1.setBalance(account.getCustomerAccountBalance());
		account1.setAccountHolderName(account.getCustomerAccountHolderName());
		manager.persist(account1);
		
		Customer customer = new Customer();
		customer.setCustomerName(account.getCustomerAccountHolderName());
		customer.setCustomerAddress(account.getCustomerAddress());
		customer.setCustomerContact(account.getCustomerContact());
		customer.setAccount(account1);
		
		manager.persist(customer);
		
		commitTransaction();
		System.out.println(account + " accountcreated saved");
		return account1;
	}

	@Override
	public void deposit(Long accountId, Double amount) {

		beginTransaction();
		Account account = manager.find(Account.class, accountId);
		System.out.println("deposit account find by id" + account);
		account.setBalance(account.getBalance() + amount);
		System.out.println("deposit account updated" + account.getBalance());
		manager.merge(account);
		Transaction transaction = new Transaction();
		transaction.setAccount(account);
		transaction.setAccountId(accountId);
		transaction.setType("DEPOSIT");
		transaction.setAmount(amount);
		transaction.setTransactionTime(LocalDateTime.now());
		manager.persist(transaction);
		commitTransaction();

	}

	@Override
	public void withdraw(Long accountId, Double amount) {

		beginTransaction();
		Account account = manager.find(Account.class, accountId);
		if (account.getBalance() >= amount) {
			account.setBalance(account.getBalance() - amount);
			manager.merge(account);

			Transaction transaction = new Transaction();
			transaction.setAccount(account);
			transaction.setAccountId(accountId);
			transaction.setType("WITHDRAW");
			transaction.setAmount(amount);
			transaction.setTransactionTime(LocalDateTime.now());
			manager.persist(transaction);
			commitTransaction();

		} else {
			throw new InsufficientFundsException("Insufficient funds");
		}
	}

	@Override
	public Double balanceInquiry(Integer accountId) {

		String sql = "select * from account where id = :accountId";
		Query query = manager.createNativeQuery(sql, Account.class);
		query.setParameter("accountId", accountId);
		Account singleResult = (Account) query.getSingleResult();
		return singleResult.getBalance();

	}

	@Override
	public List<Transaction> getLast10Transactions(Long accountId) {
		  String sql = "SELECT * FROM transaction WHERE account_id = :accountId ORDER BY transaction_time DESC LIMIT 10";
	        Query query = manager.createNativeQuery(sql, Transaction.class);
	        query.setParameter("accountId", accountId);
	        return query.getResultList();
	}

	@Override
	public void fundTransfer(Long fromAccountId, Long toAccountId, Double amount) {
		
		System.out.println(" transfer funds>>>>>>>fromAccountId: " + fromAccountId + " toAccountId: " + toAccountId + " amount: " + amount);
		
		beginTransaction();
		Account fromAccount = manager.find(Account.class, fromAccountId);
		Account toAccount = manager.find(Account.class, toAccountId);
		if (fromAccount.getBalance() >= amount) {
			fromAccount.setBalance(fromAccount.getBalance() - amount);
			toAccount.setBalance(toAccount.getBalance() + amount);
			manager.merge(fromAccount);
			manager.merge(toAccount);

			Transaction transaction = new Transaction();
			transaction.setAccount(fromAccount);
			transaction.setAccountId(fromAccountId);
			transaction.setType("TRANSFER");
			transaction.setAmount(amount);
			transaction.setTransactionTime(LocalDateTime.now());
			manager.persist(transaction);

			Transaction transaction2 = new Transaction();
			transaction2.setAccount(toAccount);
			transaction2.setAccountId(toAccountId);
			transaction2.setType("TRANSFER");
			transaction2.setAmount(amount);
			transaction2.setTransactionTime(LocalDateTime.now());
			manager.persist(transaction2);
			commitTransaction();
		} else {
			throw new InsufficientFundsException("Insufficient funds");
		}
		
		
	}
	// create customer
	
	@Override
	public Customer createCustomer(Customer customer) {
		beginTransaction();
		manager.persist(customer);
		commitTransaction();
		System.out.println(customer + " customer created saved");
		return customer;
	}

}
