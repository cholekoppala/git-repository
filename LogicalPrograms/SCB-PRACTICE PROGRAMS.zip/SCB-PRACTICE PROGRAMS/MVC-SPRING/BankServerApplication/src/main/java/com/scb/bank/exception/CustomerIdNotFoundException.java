package com.scb.bank.exception;

public class CustomerIdNotFoundException extends RuntimeException {
	

	public CustomerIdNotFoundException(String message) {
		super(message);
	}

}
