package com.scb.bank.service;

import java.util.List;

import com.scb.bank.dto.AccountWithCustomerDTO;
import com.scb.bank.entity.Account;
import com.scb.bank.entity.Customer;
import com.scb.bank.entity.Transaction;

public interface AccountService {
	
	public Account createAccount(AccountWithCustomerDTO account);
	public Customer createCustomer(Customer customer);
	public Double balanceInquiry(Integer accountId);
    public void withdraw(Long accountId, Double amount);
    public void deposit(Long accountId, Double amount);
	public List<Transaction> getLast10Transactions(Long accountId);
	public void fundTransfer(Long fromAccountId, Long toAccountId, Double amount);

    


}
