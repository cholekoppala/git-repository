package com.scb.bank.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan(basePackages = "com.scb.bank")
@EntityScan(basePackages = "com.scb.bank.entity")
public class BankServerApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(BankServerApplication.class, args);
	}

}
