package com.scb.bank.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class AccountWithCustomerDTO {

	@NotEmpty(message = "customer account no required")
	private String customerAccountNumber;
	
	private double customerAccountBalance;
	
	@NotEmpty(message = "customer accountholder name required ")
	private String customerAccountHolderName;
	
	@NotEmpty(message = "customer address  required ")
	private String customerAddress;
	
	@Pattern(regexp="(^$|[0-9]{10})")
	@Size(min = 0,max = 10)
	@NotEmpty(message = "customer contact  required ")
	private String customerContact;

	public String getCustomerAccountNumber() {
		return customerAccountNumber;
	}

	public void setCustomerAccountNumber(String customerAccountNumber) {
		this.customerAccountNumber = customerAccountNumber;
	}

	public double getCustomerAccountBalance() {
		return customerAccountBalance;
	}

	public void setCustomerAccountBalance(double customerAccountBalance) {
		this.customerAccountBalance = customerAccountBalance;
	}

	public String getCustomerAccountHolderName() {
		return customerAccountHolderName;
	}

	public void setCustomerAccountHolderName(String customerAccountHolderName) {
		this.customerAccountHolderName = customerAccountHolderName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerContact() {
		return customerContact;
	}

	public void setCustomerContact(String customerContact) {
		this.customerContact = customerContact;
	}

}
