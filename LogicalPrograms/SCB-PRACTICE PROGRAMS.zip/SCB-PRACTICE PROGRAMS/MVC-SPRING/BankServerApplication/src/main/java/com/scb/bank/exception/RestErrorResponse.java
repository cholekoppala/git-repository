package com.scb.bank.exception;
 
import java.time.LocalDateTime;
 
public class RestErrorResponse {
 
	private int statusCode;
	private LocalDateTime timestamp;
	private String message;
	public RestErrorResponse( String message) 
	{
		this.message = message;
	}
	public RestErrorResponse(int statusCode, String message, LocalDateTime timestamp) {
		this.statusCode = statusCode;
		this.message = message;
		this.timestamp = timestamp;
	}
	//no arg constructor
	public RestErrorResponse() {
	}
	//getters and setters
	public int getStatusCode() {
		return statusCode;
	}
 
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public LocalDateTime getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}
//	public void setMessage(String message) {
//		this.message = message;
//	}
	public String getMessage() {
		return message;
	}

 
}