package com.epam.practice;

public class MyMathUtils {

	private final MyCalculator calculator;

	public MyMathUtils(MyCalculator calculator) {
		this.calculator = calculator;
	}

	public int sumoftwonumbers(int n1,int n2) {
		
		return calculator.sumoftwoNumbers(n1, n2);
	}
	
	public int multiplicationtwonumbers(int n1,int n2) {
		
		return calculator.multiplicationtwonumbsers(n1, n2);
	}
	
	public static boolean evenNum(int number) {
		
		return number%2==0;
	}
	
	private boolean oddnum(int number) {
		
		return number%2==1;
	}
	
	public final String finalString() {
		
		return "finalstring method";
	}
}
