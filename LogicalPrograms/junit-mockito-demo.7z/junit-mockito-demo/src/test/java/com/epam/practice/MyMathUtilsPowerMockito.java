package com.epam.practice;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest(MyMathUtils.class)
public class MyMathUtilsPowerMockito {
	
	
	@Test
	public void staticpowerMock() {
		
		PowerMockito.mockStatic(MyMathUtils.class);
		PowerMockito.when(MyMathUtils.evenNum(2)).thenReturn(true);
		boolean result = MyMathUtils.evenNum(2);
		Assert.assertEquals(true, result);
	}
	
	//
	
	@Test
	public void finalString() {
		
		MyMathUtils mock = PowerMockito.mock(MyMathUtils.class);
		PowerMockito.when(mock.finalString()).thenReturn("finalstring method");
		String result = mock.finalString();
		Assert.assertEquals("finalstring method", result);
		
	}

}
