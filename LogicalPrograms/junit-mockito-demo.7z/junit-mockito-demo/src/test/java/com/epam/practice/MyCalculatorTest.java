/**
 * 
 */
package com.epam.practice;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


/**
 * 
 */
public class MyCalculatorTest {
	
	private MyCalculator myCalculator;
	
	private List<Integer> list;
	
	@Before
	public void setup() {
		
		myCalculator=new MyCalculator();
		list=new ArrayList<>();
		
	}
	
	@Test
	public void sumoftwoNumbers() {
		
	int sumoftwoNumbers = myCalculator.sumoftwoNumbers(2, 3);
	list.add(sumoftwoNumbers);
	Assert.assertEquals(5, sumoftwoNumbers);
	}
	
	@Test
	public void multiplicationoftwonum() {
		
		int multiplicationtwonumbsers = myCalculator.multiplicationtwonumbsers(2, 3);
		list.add(6);
		Assert.assertEquals(6, multiplicationtwonumbsers);
	}
} 
