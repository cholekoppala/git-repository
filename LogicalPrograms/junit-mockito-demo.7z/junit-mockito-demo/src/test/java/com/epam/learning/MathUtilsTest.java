package com.epam.learning;


import org.junit.*;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MathUtilsTest {

    @Mock
    private Calculator calculator1;

    @InjectMocks
    private MathUtils mathUtils;

    private static List<Integer> integerList;

    /*  @BeforeAll and @BeforeClass annotations serve same purpose
     *  @BeforeAll is from Junit5 while @BeforeClass is from junit4
     *  The method annotated with @BeforeAll or @BeforeClass  must be static
     *  It executes only once per test class execution
     *  Lifecycle : setUp-->all test methods....-->tearDown
     * */

    @BeforeClass
    public static void setUp() {
        integerList = new ArrayList<>();
        System.out.println("setUp executed");
    }


    @Test
    public void sumOfTwoNumbers() {
        when(calculator1.sumOfTwoNumbers(2, 3)).thenReturn(5);
        int result = mathUtils.sumOfTwoNumbers(2, 3);
        integerList.add(result);
        Assert.assertEquals(5, result);
    }

    @Test
    public void multiplicationOfTwoNumbers() {
        when(calculator1.multiplicationOfTwoNumbers(2, 3)).thenReturn(6);
        int result = mathUtils.multiplicationOfTwoNumbers(2, 3);
        integerList.add(result);
        Assert.assertEquals(6, result);
    }


    /*We can not mock static ,private ,final methods using plain mockito
     * It will give an error like Those methods cannot be stubbed/verified
     * That's when Power Mockito will come to rescue
     */
/*    @Test
    public void shouldReturnEvenNumber(){
        when(MathUtils.isEven(2)).thenReturn(true);
        boolean even = MathUtils.isEven(2);
        Assert.assertTrue(even);
    }*/


    @AfterClass
    public static void tearDown() {
        System.out.println(integerList);
        integerList.clear();
        System.out.println("cleaned up");
    }
}
