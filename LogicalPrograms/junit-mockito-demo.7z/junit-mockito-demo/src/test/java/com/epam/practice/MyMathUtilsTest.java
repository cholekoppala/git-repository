/**
 * 
 */
package com.epam.practice;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * 
 */
@RunWith(MockitoJUnitRunner.class)
public class MyMathUtilsTest {
	
	@Mock
	private MyCalculator myCalculator;
	
	@InjectMocks
	private MyMathUtils myMathUtils;
	
	private List<Integer> intList;
	
	@Before
	public void setup() {
		
		intList=new ArrayList<>();
		System.out.println("setup executed");
	}
	
	@Test
	public void sumoftwonumbers() {
		
		when(myCalculator.sumoftwoNumbers(2, 3)).thenReturn(5);
		int result = myMathUtils.sumoftwonumbers(2, 3);
		intList.add(5);
		Assert.assertEquals(5, result);
	}
	
    @Test
	public void multiplication() {
		
		when(myCalculator.multiplicationtwonumbsers(2, 3)).thenReturn(6);
		int result = myMathUtils.multiplicationtwonumbers(2, 3);
	    intList.add(6);
	    Assert.assertEquals(6, result);
	}

}
